const licenseSection = document.getElementById("license-section");
const activeSection = document.getElementById("active-section");
const machineIdEl = document.getElementById("machine-id");
const licenseInput = document.getElementById("license-input");
const licenseMessage = document.getElementById("license-message");
const licenseInfo = document.getElementById("license-info");
const statusAuth = document.getElementById("status-auth");

function send(m) { return new Promise(r => chrome.runtime.sendMessage(m, r)); }

async function init() {
    const status = await send({ type: "GET_LICENSE_STATUS" });
    machineIdEl.textContent = status.machineId;
    if (status.activated && status.valid) {
        licenseSection.classList.add("hidden");
        activeSection.classList.remove("hidden");
        licenseInfo.innerHTML = 'Expired: <b>' + (status.expiresAt || "-") + '</b><br>Tier: <b>' + (status.tier || "pro") + '</b>';
        await refreshStatus();
    } else {
        licenseSection.classList.remove("hidden");
        activeSection.classList.add("hidden");
        if (status.activated && !status.valid) {
            licenseMessage.innerHTML = '<span class="bad">License tidak valid: ' + status.reason + '</span>';
        }
    }
}

async function refreshStatus() {
    const status = await send({ type: "GET_STATUS" });
    if (!status.success) return;
    const lines = [];
    lines.push(status.authCaptured ? '<span class="ok">✓</span> Authorization tertangkap' : '<span class="bad">✕</span> Authorization belum');
    lines.push(status.xDgtCaptured ? '<span class="ok">✓</span> x-dgt-code tertangkap' : '<span class="bad">✕</span> x-dgt-code belum');
    const hasAny = status.hasInput || status.hasOutput || status.hasWithholding;
    lines.push(hasAny ? '<span class="ok">✓</span> Data list tertangkap' : '<span class="bad">✕</span> Belum ada list');
    statusAuth.innerHTML = lines.join("<br>");
}

document.getElementById("copy-machine").addEventListener("click", async () => {
    await navigator.clipboard.writeText(machineIdEl.textContent);
    const btn = document.getElementById("copy-machine");
    btn.textContent = "✓ Copied";
    setTimeout(() => btn.textContent = "Copy Machine ID", 1500);
});

document.getElementById("activate").addEventListener("click", async () => {
    const key = licenseInput.value.trim();
    if (!key) { licenseMessage.innerHTML = '<span class="bad">License kosong.</span>'; return; }
    licenseMessage.textContent = "Memverifikasi...";
    const result = await send({ type: "ACTIVATE_LICENSE", licenseKey: key });
    if (result.success) {
        licenseMessage.innerHTML = '<span class="ok">✓ License berhasil!' + (result.autoSynced ? ' (auto-sync)' : '') + '</span>';
        setTimeout(init, 600);
    } else licenseMessage.innerHTML = '<span class="bad">✕ ' + result.error + '</span>';
});

async function doSync() {
    const btns = [document.getElementById("syncBtn"), document.getElementById("syncBtnActive")].filter(b => b);
    btns.forEach(b => { b.disabled = true; b.textContent = "Syncing..."; });
    try {
        const res = await send({ type: "SYNC_LICENSE_WITH_BACKEND" });
        if (res && res.success) {
            licenseMessage.innerHTML = '<span class="ok">✓ ' + (res.message || "Sync berhasil") + '</span>';
            setTimeout(init, 600);
        } else {
            licenseMessage.innerHTML = '<span class="bad">✕ ' + ((res && res.error) || "Sync gagal") + '</span>';
        }
    } finally {
        btns.forEach(b => { b.disabled = false; b.textContent = "🔄 Sync"; });
    }
}

const syncBtn = document.getElementById("syncBtn");
if (syncBtn) syncBtn.addEventListener("click", doSync);
const syncBtnActive = document.getElementById("syncBtnActive");
if (syncBtnActive) syncBtnActive.addEventListener("click", doSync);

document.getElementById("refresh-status").addEventListener("click", refreshStatus);
document.getElementById("reset-license").addEventListener("click", async () => {
    if (!confirm("Reset license?")) return;
    await send({ type: "RESET_LICENSE" });
    setTimeout(init, 300);
});

init();