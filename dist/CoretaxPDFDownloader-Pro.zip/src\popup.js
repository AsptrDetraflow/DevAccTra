﻿const licenseSection = document.getElementById("license-section");
const activeSection = document.getElementById("active-section");
const machineIdEl = document.getElementById("machine-id");
const licenseInput = document.getElementById("license-input");
const licenseMessage = document.getElementById("license-message");
const licenseInfo = document.getElementById("license-info");
const statusAuth = document.getElementById("status-auth");
const hdr = document.getElementById("hdr");
const hdrTitle = document.getElementById("hdrTitle");
const hdrSub = document.getElementById("hdrSub");
const actBtn = document.getElementById("activate");
const syncWrap = document.getElementById("syncWrap");
const trialInfoEl = document.getElementById("trial-info");
const proInTrialBox = document.getElementById("pro-in-trial-box");

function send(m) { return new Promise(r => chrome.runtime.sendMessage(m, r)); }

let BUILD = { isTrialBuild: true, version: "3.1.0" };

function applyTheme() {
    if (BUILD.isTrialBuild) {
        hdr.classList.remove("full"); hdr.classList.add("trial");
        actBtn.classList.remove("full"); actBtn.classList.add("trial");
        hdrTitle.innerHTML = 'Coretax PDF Downloader<span class="badge">UNOFFICIAL</span><span class="tag trial">TRIAL</span>';
        hdrSub.textContent = 'Trial \u00B7 maks 10 PDF / 5 menit';
    } else {
        hdr.classList.remove("trial"); hdr.classList.add("full");
        actBtn.classList.remove("trial"); actBtn.classList.add("full");
        hdrTitle.innerHTML = 'Coretax PDF Downloader<span class="badge">UNOFFICIAL</span><span class="tag pro">PRO</span>';
        hdrSub.textContent = 'Pro \u00B7 Unlimited';
        const s = document.getElementById("syncBtn"); if (s) s.classList.add("full");
        const sa = document.getElementById("syncBtnActive"); if (sa) sa.classList.add("full");
    }
}

async function init() {
    try { BUILD = await send({ type: "GET_BUILD_INFO" }) || BUILD; } catch (e) {}
    applyTheme();

    const status = await send({ type: "GET_LICENSE_STATUS" });
    machineIdEl.textContent = status.machineId;

    if (status.activated && status.valid) {
        licenseSection.classList.add("hidden");
        activeSection.classList.remove("hidden");
        licenseInfo.innerHTML = 'Expired: <b>' + (status.expiresAt || "-") + '</b><br>Tier: <b>' + (status.tier || "pro") + '</b>';

        const isProLicenseInTrial = status.isProLicenseInTrialBuild;
        const scope = document.getElementById("license-scope");

        if (status.tier === "trial") {
            if (scope) {
                scope.innerHTML = 'TRIAL \u00B7 maks 10 PDF / sesi 5 menit';
                scope.style.background = "rgba(245,158,11,.1)";
                scope.style.color = "#92400E";
            }
            if (proInTrialBox) proInTrialBox.classList.add("hidden");
        } else if (isProLicenseInTrial) {
            // PRO LICENSE di TRIAL BUILD → user HARUS TAU
            if (scope) {
                scope.innerHTML = '\u26A0 VERSI TRIAL \u00B7 meskipun license PRO, tetap kena limit 10 PDF / 5 menit';
                scope.style.background = "rgba(30,91,184,.12)";
                scope.style.color = "#1E5BB8";
                scope.style.fontWeight = "700";
            }
            if (proInTrialBox) {
                proInTrialBox.classList.remove("hidden");
                proInTrialBox.innerHTML =
                    '<b>\u26A0 Kamu pakai VERSI TRIAL</b>' +
                    'License kamu <b>PRO</b>, tapi extension yang kepasang adalah <b>versi TRIAL</b>. Limit tetap 10 PDF / 5 menit. Download versi Pro untuk unlimited.' +
                    '<br><a href="https://asptrdetraflow.github.io/DevAccTra/dist/CoretaxPDFDownloader-Pro.zip" target="_blank">\u2B07 Download Versi Pro</a>';
            }
        } else {
            // Full build + license pro
            if (scope) {
                scope.innerHTML = 'PRO \u00B7 unlimited';
                scope.style.background = "rgba(0,77,47,.08)";
                scope.style.color = "#004D2F";
            }
            if (proInTrialBox) proInTrialBox.classList.add("hidden");
        }

        await refreshStatus();
    } else {
        licenseSection.classList.remove("hidden");
        activeSection.classList.add("hidden");
        if (status.activated && !status.valid) {
            licenseMessage.innerHTML = '<span class="bad">License tidak valid: ' + status.reason + '</span>';
        }
        if (BUILD.isTrialBuild && trialInfoEl) {
            trialInfoEl.classList.remove("hidden");
            trialInfoEl.innerHTML = '<b>Versi Trial</b> \u00B7 Maks 10 PDF per sesi, sesi 5 menit. Untuk unlimited, upgrade ke Pro.';
        }
        if (proInTrialBox) proInTrialBox.classList.add("hidden");
    }
}

async function refreshStatus() {
    const check = await send({ type: "CHECK_LICENSE_NOW" });
    if (check && check.valid === false) {
        licenseSection.classList.remove("hidden");
        activeSection.classList.add("hidden");
        licenseMessage.innerHTML = '<span class="bad">License tidak valid: ' + (check.reason || "invalid") + '</span>';
        return;
    }
    const status = await send({ type: "GET_STATUS" });
    if (!status.success) return;
    const lines = [];
    lines.push(status.authCaptured ? '<span class="ok">\u2713</span> Authorization tertangkap' : '<span class="bad">\u2717</span> Authorization belum');
    lines.push(status.xDgtCaptured ? '<span class="ok">\u2713</span> x-dgt-code tertangkap' : '<span class="bad">\u2717</span> x-dgt-code belum');
    const hasAny = status.hasInput || status.hasOutput || status.hasWithholding;
    lines.push(hasAny ? '<span class="ok">\u2713</span> Data list tertangkap' : '<span class="bad">\u2717</span> Belum ada list');
    statusAuth.innerHTML = lines.join("<br>");
}

if (licenseInput) {
    licenseInput.addEventListener("input", function() {
        if (syncWrap) syncWrap.classList.toggle("hidden", !licenseInput.value.trim());
    });
}

document.getElementById("copy-machine").addEventListener("click", async () => {
    await navigator.clipboard.writeText(machineIdEl.textContent);
    const btn = document.getElementById("copy-machine");
    btn.textContent = "\u2713 Copied";
    setTimeout(() => btn.textContent = "Copy Machine ID", 1500);
});

document.getElementById("activate").addEventListener("click", async () => {
    const key = licenseInput.value.trim();
    if (!key) { licenseMessage.innerHTML = '<span class="bad">License kosong.</span>'; return; }
    licenseMessage.innerHTML = '<span>Memverifikasi (butuh internet)...</span>';
    const result = await send({ type: "ACTIVATE_LICENSE", licenseKey: key });

    if (result.success) {
        licenseMessage.innerHTML = '<span class="ok">\u2713 License berhasil' + (result.serverResigned ? ' (auto-resign)' : '') + '</span>';
        setTimeout(init, 700);
        return;
    }

    // Wrong build: trial license di Pro build
    if (result.wrongBuild) {
        licenseMessage.innerHTML = '<span class="bad">\u2717 ' + result.error + '</span>';
        return;
    }

    licenseMessage.innerHTML = '<span class="bad">\u2717 ' + result.error + '</span>';
    if (result.midMismatch) {
        const mid = (await send({ type: "GET_MACHINE_ID" })).machineId || "";
        showRebindModal(mid, key, "License ini untuk device lain. Masukkan MID device lama untuk sinkronisasi.");
    }
});

async function doSync() {
    const btns = [document.getElementById("syncBtn"), document.getElementById("syncBtnActive")].filter(b => b);
    btns.forEach(b => { b.disabled = true; b.textContent = "Syncing..."; });
    try {
        const ta = document.getElementById("license-input");
        if (ta && ta.value.trim()) {
            const current = await send({ type: "GET_LICENSE_STATUS" });
            if (!current.activated || !current.payload) {
                const act = await send({ type: "ACTIVATE_LICENSE", licenseKey: ta.value.trim() });
                if (!act.success && act.midMismatch) {
                    const mid = (await send({ type: "GET_MACHINE_ID" })).machineId || "";
                    showRebindModal(mid, ta.value.trim(), "License untuk device lain.");
                    return;
                }
                if (act.success) { licenseMessage.innerHTML = '<span class="ok">\u2713 License tersimpan.</span>'; setTimeout(init, 600); return; }
                licenseMessage.innerHTML = '<span class="bad">\u2717 ' + act.error + '</span>';
                return;
            }
        }
        const res = await send({ type: "SYNC_LICENSE_WITH_BACKEND" });
        if (res && res.success) {
            licenseMessage.innerHTML = '<span class="ok">\u2713 ' + (res.message || "Sync berhasil") + '</span>';
            setTimeout(init, 600);
        } else {
            const err = (res && res.error) || "Sync gagal";
            licenseMessage.innerHTML = '<span class="bad">\u2717 ' + err + '</span>';
            if (isMismatchError(err)) {
                const mid = (await send({ type: "GET_MACHINE_ID" })).machineId || "";
                const ta2 = document.getElementById("license-input");
                showRebindModal(mid, ta2 ? ta2.value.trim() : "", "License untuk device lain.");
            }
        }
    } finally {
        btns.forEach(b => { b.disabled = false; b.textContent = "Sync"; });
    }
}
const _sb = document.getElementById("syncBtn"); if (_sb) _sb.addEventListener("click", doSync);
const _sba = document.getElementById("syncBtnActive"); if (_sba) _sba.addEventListener("click", doSync);

document.getElementById("refresh-status").addEventListener("click", refreshStatus);
document.getElementById("reset-license").addEventListener("click", async () => {
    if (!confirm("Reset license?")) return;
    await send({ type: "RESET_LICENSE" });
    setTimeout(init, 300);
});

function showRebindModal(currentMid, prefilledKey, errorMsg) {
    const modal = document.getElementById("rebindModal");
    if (!modal) return;
    document.getElementById("rebindCurrentMid").textContent = currentMid || "-";
    document.getElementById("rebindOldMid").value = "";
    const errEl = document.getElementById("rebindErr");
    errEl.style.display = "none";
    if (errorMsg) { errEl.textContent = errorMsg; errEl.style.display = "block"; }
    modal.style.display = "flex";
    setTimeout(() => document.getElementById("rebindOldMid").focus(), 150);

    document.getElementById("rebindCancel").onclick = () => { modal.style.display = "none"; };
    document.getElementById("rebindConfirm").onclick = async () => {
        const oldMid = document.getElementById("rebindOldMid").value.trim();
        errEl.style.display = "none";
        if (!/^[a-f0-9]{64}$/.test(oldMid)) { errEl.textContent = "MID harus 64 karakter hex."; errEl.style.display = "block"; return; }
        if (oldMid === currentMid) { errEl.textContent = "MID lama sama dengan device ini."; errEl.style.display = "block"; return; }

        let license = prefilledKey || "";
        if (!license) { const ta = document.getElementById("license-input"); license = ta ? ta.value.trim() : ""; }
        if (!license) { errEl.textContent = "Belum ada license. Paste dulu."; errEl.style.display = "block"; return; }

        const btn = document.getElementById("rebindConfirm");
        btn.disabled = true; btn.textContent = "Memproses...";
        try {
            const res = await send({ type: "REBIND_LICENSE", license_key: license, old_machine_id: oldMid, new_machine_id: currentMid });
            if (res && res.success) {
                btn.textContent = "Berhasil!";
                setTimeout(() => { modal.style.display = "none"; init(); }, 600);
            } else {
                errEl.textContent = (res && res.error) || "Gagal sinkron.";
                errEl.style.display = "block";
                btn.disabled = false; btn.textContent = "Sinkronkan";
            }
        } catch (e) {
            errEl.textContent = "Error: " + e.message;
            errEl.style.display = "block";
            btn.disabled = false; btn.textContent = "Sinkronkan";
        }
    };
}

function isMismatchError(msg) {
    if (!msg) return false;
    const m = msg.toLowerCase();
    return m.includes("device") || m.includes("cocok") || m.includes("lain") || m.includes("mid") || m.includes("terdaftar");
}

init();