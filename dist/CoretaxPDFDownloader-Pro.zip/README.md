# Coretax PDF Downloader

> **UNOFFICIAL TOOL** - Bulk download PDF Faktur Pajak & Bukti Potong dari portal Coretax DJP.

---

## DISCLAIMER

Produk ini **tidak berafiliasi dengan, tidak disponsori oleh, dan tidak didukung oleh** Direktorat Jenderal Pajak (DJP) Republik Indonesia. "Coretax" adalah merek terdaftar milik DJP.

Extension ini hanya alat bantu otomasi untuk mempercepat pekerjaan administratif Anda di portal Coretax DJP. Pengguna bertanggung jawab penuh atas kepatuhan terhadap ketentuan perpajakan yang berlaku.

---

## Fitur

- Auto-deteksi halaman Coretax (Faktur Keluaran / Masukan / Bukti Potong)
- Download PDF satu-per-satu (klik tombol PDF di tiap baris)
- Bulk download semua PDF sekaligus
- Tombol Stop untuk hentikan bulk download
- Retry otomatis 2x per PDF
- Panel floating - bisa drag, resize, minimize, maximize
- Sistem license aman (Ed25519 + Machine ID binding)

---

## Trial vs Pro

| Fitur | Trial | Pro |
|-------|:-----:|:---:|
| Lihat list Faktur Keluaran/Masukan/Bukti Potong | Ya | Ya |
| Download 1 PDF per baris | Ya | Ya |
| Bulk download | Max 10 PDF/sesi | Unlimited |
| Session limit | 5 menit | - |
| Retry otomatis | Ya | Ya |
| Semua fitur panel | Ya | Ya |

---

## Cara Install

1. Download ZIP (trial / pro)
2. Extract ke folder
3. Buka `chrome://extensions`
4. Aktifkan **Developer mode** (kanan atas)
5. Klik **Load unpacked** lalu pilih folder hasil extract
6. Extension siap dipakai

---

## Cara Pakai

1. Login ke `coretaxdjp.pajak.go.id`
2. Buka salah satu halaman:
   - Faktur Pajak Keluaran
   - Faktur Pajak Masukan
   - My Withholding Slips
3. Refresh halaman (F5)
4. Panel otomatis muncul di kanan atas
5. Klik **Download All** untuk bulk download, atau tombol **PDF** per baris

---

## License

- **Trial:** generate otomatis dari halaman trial
- **Pro:** hubungi admin untuk pembelian

Saat pertama pakai, panel akan menampilkan **Machine ID** Anda. Kirim Machine ID ini ke penjual untuk mendapat License Key.

---

## Kompatibilitas

- Chrome 88+
- Microsoft Edge 88+
- Brave, Opera, Vivaldi (Chromium-based)
- Firefox TIDAK didukung (WebRequest API berbeda)

---

## Kontak

- Portfolio: https://asptrdetraflow.github.io/Ade-Saputra-Profile/
- Produk: https://asptrdetraflow.github.io/DevAccTra/

---

**Coretax PDF Downloader** (c) 2026 - Tidak berafiliasi dengan DJP