// ============================================================
// Coretax PDF Downloader — Background v3.0
// Verify license + auto-sync dengan backend
// ============================================================
const CORE_URL = "https://coretaxdjp.pajak.go.id";
const API_URL = "https://devacctra-api.up.railway.app";
const DASHBOARD_URL = "https://asptrdetraflow.github.io/DevAccTra/dashboard/";

const INPUT_LIST_URL       = `${CORE_URL}/einvoiceportal/api/inputinvoice/list`;
const OUTPUT_LIST_URL      = `${CORE_URL}/einvoiceportal/api/outputinvoice/list`;
const INVOICE_DOWNLOAD_URL = `${CORE_URL}/einvoiceportal/api/downloadinvoice/download-invoice-document`;
const WITHHOLDING_LIST_URL     = `${CORE_URL}/withholdingslipsportal/api/GetMyWithholdingSlip`;
const WITHHOLDING_DOWNLOAD_URL = `${CORE_URL}/withholdingslipsportal/api/DownloadWithholdingSlips/download-pdf-document`;

const LICENSE_PUBLIC_KEY_B64 = "kN08rrwZddPxF2KjSIgZ0bH6veMmE94ExuEE3FbGs6s=";

// ============================================================
// TRIAL GUARD
// ============================================================
const TRIAL_MAX_DOWNLOADS = 10;
const TRIAL_SESSION_MS = 5 * 60 * 1000;
let trialState = { sessionStart: Date.now(), downloadCount: 0, isTrial: false };

async function initTrialState() { trialState.isTrial = true; }
initTrialState();

function trialBlockReason() {
    if (!trialState.isTrial) return null;
    const elapsed = Date.now() - trialState.sessionStart;
    if (elapsed >= TRIAL_SESSION_MS) return "Sesi trial 5 menit habis. Refresh halaman Coretax untuk sesi baru.";
    if (trialState.downloadCount >= TRIAL_MAX_DOWNLOADS) return "Limit trial: maks " + TRIAL_MAX_DOWNLOADS + " PDF/sesi.";
    return null;
}
function trialRecordDownload() {
    if (trialState.isTrial) trialState.downloadCount++;
}
function trialResetSession() {
    trialState.sessionStart = Date.now();
    trialState.downloadCount = 0;
}

// ============================================================
// CRYPTO HELPERS
// ============================================================
function b64ToBytes(b64) {
    const bin = atob(b64);
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    return bytes;
}
function b64urlToBytes(str) {
    str = str.replace(/-/g, "+").replace(/_/g, "/");
    while (str.length % 4) str += "=";
    const bin = atob(str);
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    return bytes;
}
let _publicKeyCache = null;
async function getPublicKey() {
    if (_publicKeyCache) return _publicKeyCache;
    if (LICENSE_PUBLIC_KEY_B64 === "__CORETAX_PUBLIC_KEY_B64__") {
        throw new Error("PUBLIC_KEY_NOT_SET");
    }
    _publicKeyCache = await crypto.subtle.importKey(
        "raw", b64ToBytes(LICENSE_PUBLIC_KEY_B64),
        { name: "Ed25519" }, false, ["verify"]
    );
    return _publicKeyCache;
}

// ============================================================
// MACHINE ID
// ============================================================
async function getMachineId(forceRefresh) {
    if (!forceRefresh) {
        const stored = await chrome.storage.local.get("machine_id");
        if (stored.machine_id) return stored.machine_id;
    }
    const parts = [
        navigator.platform || "",
        navigator.hardwareConcurrency || 0,
        navigator.deviceMemory || 0,
        navigator.language || "",
        (navigator.userAgentData && navigator.userAgentData.platform) || "",
        Intl.DateTimeFormat().resolvedOptions().timeZone || "",
        new Date().getTimezoneOffset(),
        navigator.userAgent || ""
    ];
    const fp = parts.join("|");
    const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(fp));
    const hex = [...new Uint8Array(buf)].map(b => b.toString(16).padStart(2, "0")).join("");
    await chrome.storage.local.set({ machine_id: hex });
    return hex;
}

// ============================================================
// VERIFY LICENSE (multi-source MID)
// ============================================================
async function verifyLicenseKey(licenseKey) {
    try {
        const parts = licenseKey.trim().split(".");
        if (parts.length !== 2) return { valid: false, reason: "Format license tidak valid" };
        const [payloadB64, sigB64] = parts;
        const publicKey = await getPublicKey();
        const signature = b64urlToBytes(sigB64);
        const data = new TextEncoder().encode(payloadB64);
        const ok = await crypto.subtle.verify({ name: "Ed25519" }, publicKey, signature, data);
        if (!ok) return { valid: false, reason: "License tidak sah" };

        const payload = JSON.parse(new TextDecoder().decode(b64urlToBytes(payloadB64)));

        const allowedMids = Array.isArray(payload.m) ? payload.m : [payload.m];
        const isWildcard = allowedMids.includes("*");
        if (isWildcard) {
            const today = new Date().toISOString().slice(0, 10);
            if (payload.e < today) return { valid: false, reason: "License kadaluarsa", payload };
            if (payload.t === "trial") return { valid: false, reason: "License trial tidak bisa dipakai di full version.", payload };
            return { valid: true, payload };
        }

        // Source 1: MID cache
        const cachedMid = await getMachineId(false);
        if (allowedMids.includes(cachedMid)) {
            const today = new Date().toISOString().slice(0, 10);
            if (payload.e < today) return { valid: false, reason: "License kadaluarsa", payload };
            if (payload.t === "trial") return { valid: false, reason: "License trial tidak bisa dipakai di full version.", payload };
            return { valid: true, payload };
        }

        // Source 2: Fresh fingerprint
        try {
            const freshMid = await getMachineId(true);
            if (allowedMids.includes(freshMid)) {
                const today = new Date().toISOString().slice(0, 10);
                if (payload.e < today) return { valid: false, reason: "License kadaluarsa", payload };
                if (payload.t === "trial") return { valid: false, reason: "License trial tidak bisa dipakai di full version.", payload };
                return { valid: true, payload };
            }
        } catch (e) {}

        return {
            valid: false,
            reason: "License tidak cocok dengan device ini",
            payload,
            allowedMids,
            currentMid: cachedMid,
        };
    } catch (e) {
        if (e.message === "PUBLIC_KEY_NOT_SET") {
            return { valid: false, reason: "Public key belum di-setup." };
        }
        return { valid: false, reason: "Error: " + e.message };
    }
}

// ============================================================
// BACKEND SYNC
// ============================================================
async function syncLicenseWithBackend(licenseKey) {
    try {
        const mid = await getMachineId(true);
        const resp = await fetch(API_URL + "/api/license/verify-and-resign", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ machine_id: mid, license_key: licenseKey || null }),
        });
        let data;
        try { data = await resp.json(); } catch (e) { data = { detail: "Invalid JSON" }; }
        if (!resp.ok) return { ok: false, status: resp.status, error: data.detail || "Server error" };
        return { ok: true, data };
    } catch (e) {
        return { ok: false, error: e.message };
    }
}

async function getLicenseStatus() {
    const stored = await chrome.storage.local.get("license_key");
    const machineId = await getMachineId();
    if (!stored.license_key) return { activated: false, valid: false, machineId };

    const result = await verifyLicenseKey(stored.license_key);

    if (result.valid) {
        // Fire-and-forget backend sync
        syncLicenseWithBackend(stored.license_key).then(sync => {
            if (sync.ok && sync.data.status === "resigned" && sync.data.license_key) {
                chrome.storage.local.set({ license_key: sync.data.license_key });
                console.log("[License] Auto-resigned by backend");
            }
        }).catch(() => {});
        return {
            activated: true, valid: true,
            payload: result.payload,
            expiresAt: result.payload?.e,
            issuedAt: result.payload?.i,
            tier: result.payload?.t,
            machineId,
        };
    }

    // Local verify FAILED → try sync sinkron
    console.log("[License] Local fail:", result.reason, "→ trying backend sync");
    const sync = await syncLicenseWithBackend(stored.license_key);
    if (sync.ok && sync.data.status === "resigned" && sync.data.license_key) {
        await chrome.storage.local.set({ license_key: sync.data.license_key });
        const reVerify = await verifyLicenseKey(sync.data.license_key);
        if (reVerify.valid) {
            console.log("[License] Sync success");
            return {
                activated: true, valid: true,
                payload: reVerify.payload,
                expiresAt: reVerify.payload?.e,
                issuedAt: reVerify.payload?.i,
                tier: reVerify.payload?.t,
                machineId,
                autoSynced: true,
            };
        }
    }

    return {
        activated: true, valid: false,
        reason: (sync.ok && sync.data.message) ? sync.data.message : (result.reason || "License tidak valid"),
        payload: result.payload,
        expiresAt: result.payload?.e,
        issuedAt: result.payload?.i,
        tier: result.payload?.t,
        machineId,
        syncTried: true,
    };
}

// ============================================================
// STATE CAPTURE (headers + request bodies)
// ============================================================
let latestAuth = { authorization: null, xDgtCode: null };
const captured = { input: null, output: null, withholding: null };
const downloadState = {
    running: false, stopRequested: false, total: 0,
    completed: 0, failed: 0, current: null, results: []
};

function getActiveInvoiceMode() {
    const inp = captured.input, out = captured.output;
    if (!inp && !out) return null;
    if (!inp) return "output";
    if (!out) return "input";
    return inp.capturedAt > out.capturedAt ? "input" : "output";
}
function headerValue(headers, name) {
    if (!headers) return null;
    const target = name.toLowerCase();
    const found = headers.find(h => h.name && h.name.toLowerCase() === target);
    return found ? found.value : null;
}
function parseRequestBody(requestBody) {
    if (!requestBody || !requestBody.raw) return null;
    try {
        const chunks = requestBody.raw.map(item => item.bytes).filter(Boolean);
        if (!chunks.length) return null;
        const combined = new Uint8Array(chunks.reduce((t, c) => t + c.byteLength, 0));
        let offset = 0;
        for (const chunk of chunks) {
            const bytes = new Uint8Array(chunk);
            combined.set(bytes, offset);
            offset += bytes.length;
        }
        return new TextDecoder("utf-8").decode(combined);
    } catch (e) { return null; }
}
function clone(v) { return structuredClone(v); }
function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }
function normalizeDocumentDate(value) {
    if (!value) return null;
    return String(value).replace("Z", "").replace(/[+-]\d{2}:\d{2}$/, "");
}
function sanitizeFilename(name, fallback) {
    if (!name) return fallback || "coretax.pdf";
    let f = String(name).replace(/[<>:"/\\|?*\x00-\x1F]/g, "_").trim();
    if (!f.toLowerCase().endsWith(".pdf")) f += ".pdf";
    return f;
}

chrome.webRequest.onBeforeSendHeaders.addListener(
    details => {
        if (!details.url.startsWith(CORE_URL)) return;
        const auth = headerValue(details.requestHeaders, "authorization");
        const xDgt = headerValue(details.requestHeaders, "x-dgt-code");
        if (auth) latestAuth.authorization = auth;
        if (xDgt) latestAuth.xDgtCode = xDgt;
    },
    { urls: [`${CORE_URL}/*`] },
    ["requestHeaders", "extraHeaders"]
);

chrome.webRequest.onBeforeRequest.addListener(
    details => {
        if (details.method !== "POST") return;
        const url = details.url;
        let kind = null;
        if (url === INPUT_LIST_URL) kind = "input";
        else if (url === OUTPUT_LIST_URL) kind = "output";
        else if (url === WITHHOLDING_LIST_URL) kind = "withholding";
        else return;
        const body = parseRequestBody(details.requestBody);
        if (!body) return;
        try {
            captured[kind] = { payload: JSON.parse(body), capturedAt: Date.now(), tabId: details.tabId };
        } catch (e) { console.error(`Invalid ${kind} JSON`); }
    },
    { urls: [INPUT_LIST_URL, OUTPUT_LIST_URL, WITHHOLDING_LIST_URL] },
    ["requestBody"]
);

async function coretaxFetch(url, body) {
    const headers = { "Accept": "application/json, text/plain, */*", "Content-Type": "application/json" };
    if (latestAuth.authorization) headers["Authorization"] = latestAuth.authorization;
    if (latestAuth.xDgtCode) headers["x-dgt-code"] = latestAuth.xDgtCode;
    const response = await fetch(url, {
        method: "POST", headers, body: JSON.stringify(body), credentials: "include"
    });
    const text = await response.text();
    let json;
    try { json = JSON.parse(text); }
    catch { throw new Error(`Coretax return non-JSON (HTTP ${response.status})`); }
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    if (json && json.IsSuccessful === false) throw new Error(json.Message || json.ErrorMessage || "Coretax request gagal");
    return json;
}

async function getInvoiceList(mode, customPayload = null) {
    const capturedReq = captured[mode];
    if (!customPayload && !capturedReq) {
        throw new Error(`Belum ada request Faktur ${mode === "input" ? "Masukan" : "Keluaran"}. Buka halaman list-nya lalu refresh.`);
    }
    const payload = customPayload ? clone(customPayload) : clone(capturedReq.payload);
    const url = mode === "output" ? OUTPUT_LIST_URL : INPUT_LIST_URL;
    return await coretaxFetch(url, payload);
}
async function getWithholdingList(customPayload = null) {
    if (!customPayload && !captured.withholding) {
        throw new Error("Belum ada request Bukti Potong. Buka halaman My Withholding Slips lalu refresh.");
    }
    const payload = customPayload ? clone(customPayload) : clone(captured.withholding.payload);
    return await coretaxFetch(WITHHOLDING_LIST_URL, payload);
}

function buildInvoiceDownloadPayload(row, mode) {
    if (mode === "output") {
        return {
            DocumentAggregateIdentifier: row.DocumentFormAggregateIdentifier,
            DocumentDate: normalizeDocumentDate(row.LastUpdatedDate) || normalizeDocumentDate(row.TaxInvoiceDate),
            EInvoiceAggregateIdentifier: row.AggregateIdentifier,
            EInvoiceMenuType: "Outgoing",
            EInvoiceRecordIdentifier: row.RecordId,
            LetterNumber: row.TaxInvoiceNumber,
            TaxInvoiceStatus: row.TaxInvoiceStatus,
            TaxpayerAggregateIdentifier: row.SellerTaxpayerAggregateIdentifier
        };
    }
    return {
        EInvoiceRecordIdentifier: row.RecordId,
        EInvoiceAggregateIdentifier: row.AggregateIdentifier,
        DocumentAggregateIdentifier: row.DocumentFormAggregateIdentifier,
        TaxpayerAggregateIdentifier: row.BuyerTaxpayerAggregateIdentifier,
        LetterNumber: row.TaxInvoiceNumber,
        DocumentDate: normalizeDocumentDate(row.LastUpdatedDate) || normalizeDocumentDate(row.TaxInvoiceDate),
        EInvoiceMenuType: "Input",
        TaxInvoiceStatus: row.TaxInvoiceStatus
    };
}
function buildWithholdingDownloadPayload(row) {
    return {
        WithholdingSlipsAggregateIdentifier: row.WithholdingslipsAggregateIdentifier,
        WithholdingSlipsRecordIdentifier: row.RecordId,
        DocumentAggregateIdentifier: row.DocumentFormAggregateIdentifier,
        TaxpayerAggregateIdentifier: row.TaxpayerAggregateIdentifier,
        EbupotType: row.__EbupotType || captured.withholding?.payload?.WithholdingType || "EBUPOTBPU",
        DocumentDate: normalizeDocumentDate(row.LastUpdatedDate) || normalizeDocumentDate(row.CreationDate) || normalizeDocumentDate(row.WithholdingSlipsDate),
        TaxIdentificationNumber: row.TaxIdentificationNumber
    };
}

async function downloadInvoice(row, mode) {
    trialRecordDownload();
    const payload = buildInvoiceDownloadPayload(row, mode);
    const result = await coretaxFetch(INVOICE_DOWNLOAD_URL, payload);
    const message = result?.Payload?.Message || null;
    const data = message?.Data || result?.Content || null;
    if (!message && !result.Content) throw new Error("Response tidak ada PDF.");
    if (message && message.IsSuccessful === false) throw new Error(message.ErrorMessage || result.Message || "Coretax gagal buat PDF.");
    if (!data) throw new Error("Data Base64 PDF tidak ditemukan.");
    const filename = sanitizeFilename(message?.FileName || result?.FileName, `Coretax_${row.TaxInvoiceNumber || row.RecordId}.pdf`);
    await chrome.downloads.download({
        url: `data:application/pdf;base64,${data}`, filename,
        saveAs: false, conflictAction: "uniquify"
    });
    return { success: true, filename, invoiceNumber: row.TaxInvoiceNumber };
}
async function downloadWithholding(row) {
    trialRecordDownload();
    const payload = buildWithholdingDownloadPayload(row);
    const result = await coretaxFetch(WITHHOLDING_DOWNLOAD_URL, payload);
    const message = result?.Payload?.Message || null;
    if (!message && !result?.Content) throw new Error("Response tidak ada PDF.");
    if (message && message.IsSuccessful === false) throw new Error(message.ErrorMessage || result.Message || "Coretax gagal buat PDF.");
    const base64 = message?.Data || result?.Content || null;
    if (!base64) throw new Error("Data Base64 PDF tidak ditemukan.");
    const filename = sanitizeFilename(message?.FileName || result?.FileName, `Coretax_${row.WithholdingSlipsNumber || row.RecordId}.pdf`);
    await chrome.downloads.download({
        url: `data:application/pdf;base64,${base64}`, filename,
        saveAs: false, conflictAction: "uniquify"
    });
    return { success: true, filename, withholdingNumber: row.WithholdingSlipsNumber, recordId: row.RecordId };
}

async function downloadAll(kind, rows) {
    if (downloadState.running) throw new Error("Download All sedang berjalan.");
    downloadState.running = true;
    downloadState.stopRequested = false;
    downloadState.total = rows.length;
    downloadState.completed = 0;
    downloadState.failed = 0;
    downloadState.current = null;
    downloadState.results = [];
    try {
        for (let i = 0; i < rows.length; i++) {
            if (downloadState.stopRequested) break;
            const row = rows[i];
            downloadState.current = { index: i + 1, invoiceNumber: row.TaxInvoiceNumber || row.WithholdingSlipsNumber || "-" };
            let success = false, lastError = null;
            for (let attempt = 1; attempt <= 2; attempt++) {
                try {
                    const result = kind === "withholding" ? await downloadWithholding(row) : await downloadInvoice(row, kind);
                    downloadState.completed++;
                    downloadState.results.push({ ...result, status: "success" });
                    success = true;
                    break;
                } catch (error) {
                    lastError = error;
                    if (attempt < 2) await sleep(1200);
                }
            }
            if (!success) {
                downloadState.failed++;
                downloadState.results.push({
                    invoiceNumber: row.TaxInvoiceNumber || row.WithholdingSlipsNumber || "-",
                    status: "failed", error: lastError?.message || "Unknown error"
                });
            }
            await sleep(300);
        }
    } finally {
        downloadState.running = false;
        downloadState.current = null;
    }
    return clone(downloadState);
}

async function getAllInvoice(mode) {
    const capturedReq = captured[mode];
    if (!capturedReq) throw new Error("Belum ada request list.");
    const base = clone(capturedReq.payload);
    let rowsPerPage = Number(base.Rows) || 10;
    let first = Number(base.First || 0);
    const firstResp = await getInvoiceList(mode, { ...clone(base), First: first, Rows: rowsPerPage });
    const firstData = firstResp?.Payload?.Data || [];
    const total = Number(firstResp?.Payload?.TotalRecords || firstData.length);
    const all = [...firstData];
    const totalPages = Math.ceil(total / rowsPerPage);
    for (let page = 1; page < totalPages; page++) {
        const nextFirst = first + page * rowsPerPage;
        const payload = clone(base);
        payload.First = nextFirst;
        payload.Rows = rowsPerPage;
        const resp = await getInvoiceList(mode, payload);
        const data = resp?.Payload?.Data || [];
        if (!data.length) break;
        all.push(...data);
    }
    return { rows: all, totalRecords: total, rowsPerPage };
}
async function getAllWithholding() {
    if (!captured.withholding) throw new Error("Belum ada request Bukti Potong.");
    const base = clone(captured.withholding.payload);
    let rowsPerPage = Number(base.Rows) || 10;
    let first = Number(base.First || 0);
    const firstResp = await getWithholdingList({ ...clone(base), First: first, Rows: rowsPerPage });
    const firstData = firstResp?.Payload?.Data || [];
    const total = Number(firstResp?.Payload?.TotalRecords || firstData.length);
    firstData.forEach(row => { row.__EbupotType = base.WithholdingType || "EBUPOTBPU"; });
    const all = [...firstData];
    const totalPages = Math.ceil(total / rowsPerPage);
    for (let page = 1; page < totalPages; page++) {
        const nextFirst = first + page * rowsPerPage;
        const payload = clone(base);
        payload.First = nextFirst;
        payload.Rows = rowsPerPage;
        const resp = await getWithholdingList(payload);
        const data = resp?.Payload?.Data || [];
        if (!data.length) break;
        data.forEach(row => { row.__EbupotType = base.WithholdingType || "EBUPOTBPU"; });
        all.push(...data);
    }
    return { rows: all, totalRecords: total, rowsPerPage };
}

// ============================================================
// MESSAGE HANDLERS
// ============================================================
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === "GET_LICENSE_STATUS") { getLicenseStatus().then(sendResponse); return true; }
    if (message.type === "GET_MACHINE_ID") { getMachineId().then(id => sendResponse({ machineId: id })); return true; }

    if (message.type === "ACTIVATE_LICENSE") {
        (async () => {
            const result = await verifyLicenseKey(message.licenseKey);
            if (result.valid) {
                await chrome.storage.local.set({ license_key: message.licenseKey.trim() });
                sendResponse({ success: true, payload: result.payload });
            } else {
                // Coba sync backend dulu
                const sync = await syncLicenseWithBackend(message.licenseKey);
                if (sync.ok && sync.data.status === "resigned" && sync.data.license_key) {
                    await chrome.storage.local.set({ license_key: sync.data.license_key });
                    const reVerify = await verifyLicenseKey(sync.data.license_key);
                    if (reVerify.valid) {
                        sendResponse({ success: true, payload: reVerify.payload, autoSynced: true });
                        return;
                    }
                }
                sendResponse({ success: false, error: result.reason });
            }
        })();
        return true;
    }

    if (message.type === "SYNC_LICENSE_WITH_BACKEND") {
        (async () => {
            const stored = await chrome.storage.local.get("license_key");
            if (!stored.license_key) {
                sendResponse({ success: false, error: "Belum ada license di-paste." });
                return;
            }
            const sync = await syncLicenseWithBackend(stored.license_key);
            if (sync.ok && sync.data.license_key) {
                await chrome.storage.local.set({ license_key: sync.data.license_key });
                sendResponse({ success: true, status: sync.data.status, message: sync.data.message, license_key: sync.data.license_key });
            } else if (sync.ok) {
                sendResponse({ success: true, status: sync.data.status, message: sync.data.message });
            } else {
                sendResponse({ success: false, error: sync.error || sync.data?.message || "Sync gagal" });
            }
        })();
        return true;
    }

    if (message.type === "RESET_MACHINE_ID") {
        (async () => {
            await chrome.storage.local.remove("machine_id");
            const fresh = await getMachineId(true);
            sendResponse({ success: true, machineId: fresh });
        })();
        return true;
    }

    if (message.type === "RESET_LICENSE") {
        (async () => { await chrome.storage.local.remove("license_key"); sendResponse({ success: true }); })();
        return true;
    }

    if (message.type === "RESET_TRIAL_SESSION") {
        trialResetSession();
        sendResponse({ success: true, remaining: TRIAL_MAX_DOWNLOADS });
        return true;
    }

    if (message.type === "GET_TRIAL_STATE") {
        const elapsed = Date.now() - trialState.sessionStart;
        const remainingMs = Math.max(0, TRIAL_SESSION_MS - elapsed);
        const remainingDl = Math.max(0, TRIAL_MAX_DOWNLOADS - trialState.downloadCount);
        sendResponse({
            isTrial: trialState.isTrial,
            remainingMs, remainingDownloads: remainingDl,
            blocked: !!trialBlockReason(),
            blockReason: trialBlockReason()
        });
        return true;
    }

    if (message.type === "GET_STATUS") {
        sendResponse({
            success: true,
            authCaptured: !!latestAuth.authorization,
            xDgtCaptured: !!latestAuth.xDgtCode,
            hasInput: !!captured.input,
            hasOutput: !!captured.output,
            hasWithholding: !!captured.withholding,
            activeInvoiceMode: getActiveInvoiceMode(),
            downloadState: clone(downloadState)
        });
        return true;
    }

    if (message.type === "GET_INVOICE_LIST") {
        const mode = getActiveInvoiceMode();
        if (!mode) { sendResponse({ success: false, error: "Belum ada request Faktur Pajak." }); return true; }
        getInvoiceList(mode).then(r => sendResponse({ success: true, data: r, mode }))
            .catch(e => sendResponse({ success: false, error: e.message }));
        return true;
    }
    if (message.type === "GET_INVOICE_ALL") {
        const mode = getActiveInvoiceMode();
        if (!mode) { sendResponse({ success: false, error: "Belum ada request Faktur Pajak." }); return true; }
        getAllInvoice(mode).then(r => sendResponse({ success: true, ...r, mode }))
            .catch(e => sendResponse({ success: false, error: e.message }));
        return true;
    }
    if (message.type === "GET_WITHHOLDING_LIST") {
        getWithholdingList().then(r => sendResponse({ success: true, data: r }))
            .catch(e => sendResponse({ success: false, error: e.message }));
        return true;
    }
    if (message.type === "GET_WITHHOLDING_ALL") {
        getAllWithholding().then(r => sendResponse({ success: true, ...r }))
            .catch(e => sendResponse({ success: false, error: e.message }));
        return true;
    }
    if (message.type === "DOWNLOAD_INVOICE_ONE") {
        const trialReason = trialBlockReason();
        if (trialReason) { sendResponse({ success: false, error: trialReason }); return true; }
        const mode = getActiveInvoiceMode();
        if (!mode) { sendResponse({ success: false, error: "Mode tidak diketahui." }); return true; }
        downloadInvoice(message.row, mode).then(r => sendResponse({ success: true, result: r }))
            .catch(e => sendResponse({ success: false, error: e.message }));
        return true;
    }
    if (message.type === "DOWNLOAD_WITHHOLDING_ONE") {
        const trialReason = trialBlockReason();
        if (trialReason) { sendResponse({ success: false, error: trialReason }); return true; }
        downloadWithholding(message.row).then(r => sendResponse({ success: true, result: r }))
            .catch(e => sendResponse({ success: false, error: e.message }));
        return true;
    }
    if (message.type === "DOWNLOAD_INVOICE_ALL") {
        if (trialState.isTrial) {
            const remaining = TRIAL_MAX_DOWNLOADS - trialState.downloadCount;
            if (remaining <= 0) { sendResponse({ success: false, error: "Limit trial habis." }); return true; }
            const capped = (message.rows || []).slice(0, remaining);
            downloadAll("output", capped)
                .then(r => sendResponse({ success: true, result: r, capped: true }))
                .catch(e => sendResponse({ success: false, error: e.message }));
            return true;
        }
        const mode = getActiveInvoiceMode();
        if (!mode) { sendResponse({ success: false, error: "Mode tidak diketahui." }); return true; }
        downloadAll(mode, message.rows).then(r => sendResponse({ success: true, result: r }))
            .catch(e => sendResponse({ success: false, error: e.message }));
        return true;
    }
    if (message.type === "DOWNLOAD_WITHHOLDING_ALL") {
        if (trialState.isTrial) {
            const remaining = TRIAL_MAX_DOWNLOADS - trialState.downloadCount;
            if (remaining <= 0) { sendResponse({ success: false, error: "Limit trial habis." }); return true; }
            const capped = (message.rows || []).slice(0, remaining);
            downloadAll("withholding", capped)
                .then(r => sendResponse({ success: true, result: r, capped: true }))
                .catch(e => sendResponse({ success: false, error: e.message }));
            return true;
        }
        downloadAll("withholding", message.rows).then(r => sendResponse({ success: true, result: r }))
            .catch(e => sendResponse({ success: false, error: e.message }));
        return true;
    }
    if (message.type === "STOP_DOWNLOAD") {
        downloadState.stopRequested = true;
        sendResponse({ success: true });
        return true;
    }
});

// ============================================================
// ON INSTALL
// ============================================================
chrome.runtime.onInstalled.addListener((details) => {
    if (details.reason === "install") {
        chrome.tabs.create({ url: chrome.runtime.getURL("src/welcome.html") });
    }
});