// ============================================================
// Coretax PDF Downloader — Welcome Page Logic
// (Dipisah dari HTML karena MV3 CSP block inline script)
// ============================================================

const $ = (s, r = document) => r.querySelector(s);

function sendMessage(msg) {
    return new Promise((resolve) => {
        try {
            chrome.runtime.sendMessage(msg, (resp) => {
                if (chrome.runtime.lastError) {
                    resolve({ ok: false, error: chrome.runtime.lastError.message });
                    return;
                }
                resolve(resp);
            });
        } catch (e) {
            resolve({ ok: false, error: e.message });
        }
    });
}

function copyText(text, btn) {
    if (!text) return;
    navigator.clipboard.writeText(text).then(() => {
        const orig = btn.textContent;
        btn.classList.add("copied");
        btn.textContent = "Tersalin!";
        setTimeout(() => {
            btn.classList.remove("copied");
            btn.textContent = orig;
        }, 1800);
    }).catch(() => {
        alert("Gagal copy. Silakan copy manual.");
    });
}

// ============ INIT: Get Machine ID ============
(async function init() {
    const midInput = $("#machineId");
    if (!midInput) return;
    const res = await sendMessage({ type: "GET_MACHINE_ID" });
    if (res && res.machineId) {
        midInput.value = res.machineId;
    } else {
        midInput.value = "Error: " + (res && res.error ? res.error : "tidak terdeteksi");
    }
})();

// ============ Copy Machine ID ============
document.addEventListener("DOMContentLoaded", () => {
    const copyMidBtn = $("#copyMid");
    if (copyMidBtn) {
        copyMidBtn.addEventListener("click", () => {
            const mid = $("#machineId").value;
            if (!mid || mid.startsWith("Error")) return;
            navigator.clipboard.writeText(mid).then(() => {
                copyMidBtn.classList.add("ok");
                copyMidBtn.textContent = "OK!";
                setTimeout(() => {
                    copyMidBtn.classList.remove("ok");
                    copyMidBtn.textContent = "Copy";
                }, 1500);
            });
        });
    }

    // ============ Form Submit: Generate Trial ============
    const trialForm = $("#trialForm");
    if (trialForm) {
        trialForm.addEventListener("submit", async (e) => {
            e.preventDefault();

            const name = $("#name").value.trim();
            const email = $("#email").value.trim();
            const machineId = $("#machineId").value.trim();
            const btn = $("#submitBtn");
            const errBox = $("#errorBox");
            const warnBox = $("#warnBox");

            errBox.style.display = "none";
            warnBox.style.display = "none";

            if (!name || !email || !machineId) return;
            if (machineId.startsWith("Error") || machineId.startsWith("Memuat")) {
                errBox.style.display = "flex";
                errBox.textContent = "Machine ID belum terdeteksi. Reload halaman extension ini.";
                return;
            }

            btn.disabled = true;
            btn.innerHTML = '<span class="spinner"></span> Memproses...';

            try {
                const resp = await sendMessage({
                    type: "GENERATE_TRIAL_LICENSE",
                    payload: {
                        name: name,
                        email: email,
                        tool: "coretax-toolkit",
                        machine_id: machineId,
                    },
                });

                if (!resp || !resp.ok) {
                    errBox.style.display = "flex";
                    errBox.textContent = "Error: " + ((resp && resp.error) || "Gagal menghubungi server.");
                    return;
                }

                const data = resp.data;

                if (data.success) {
                    $("#licenseKeyBox").textContent = data.license_key;
                    $("#step2").classList.add("dim");
                    const step3 = $("#step3");
                    step3.classList.remove("dim");
                    step3.classList.add("success");
                    $("#successContent").style.display = "block";
                    setTimeout(() => step3.scrollIntoView({ behavior: "smooth", block: "start" }), 200);
                } else if (data.already_trialed) {
                    warnBox.style.display = "flex";
                    if (data.is_active && data.license_key) {
                        warnBox.innerHTML =
                            '<div><b>Email ini sudah pernah trial.</b> License masih aktif sampai <b>' +
                            (data.expires_at || "") +
                            '</b>.<div class="license-box" style="margin-top:10px">' +
                            data.license_key +
                            '</div><button class="btn-copy" id="copyOldBtn" style="margin-top:8px">Copy License Key</button></div>';
                        const oldBtn = document.getElementById("copyOldBtn");
                        if (oldBtn) {
                            oldBtn.addEventListener("click", (ev) => copyText(data.license_key, ev.currentTarget));
                        }
                    } else {
                        warnBox.textContent = "Email ini sudah pernah trial dan sudah kadaluarsa. Hubungi kami untuk upgrade.";
                    }
                } else {
                    errBox.style.display = "flex";
                    errBox.textContent = data.error || "Gagal memproses.";
                }
            } catch (err) {
                errBox.style.display = "flex";
                errBox.textContent = "Error: " + err.message;
            } finally {
                btn.disabled = false;
                btn.textContent = "Generate License Trial";
            }
        });
    }

    // ============ Copy License ============
    const copyBtn = $("#copyBtn");
    if (copyBtn) {
        copyBtn.addEventListener("click", (e) => {
            copyText($("#licenseKeyBox").textContent, e.currentTarget);
        });
    }
});