﻿// ============================================================
// Coretax PDF Downloader — Background v3.1.0
// Bugfix: stable MID + strict activate + trial/Pro build awareness
// ============================================================
const CORE_URL = "https://coretaxdjp.pajak.go.id";
const API_URL = "https://devacctra-api.up.railway.app";
const DASHBOARD_URL = "https://asptrdetraflow.github.io/DevAccTra/dashboard/";

const INPUT_LIST_URL       = `${CORE_URL}/einvoiceportal/api/inputinvoice/list`;
const OUTPUT_LIST_URL      = `${CORE_URL}/einvoiceportal/api/outputinvoice/list`;
const INVOICE_DOWNLOAD_URL = `${CORE_URL}/einvoiceportal/api/downloadinvoice/download-invoice-document`;
const WITHHOLDING_LIST_URL     = `${CORE_URL}/withholdingslipsportal/api/GetMyWithholdingSlip`;
const WITHHOLDING_DOWNLOAD_URL = `${CORE_URL}/withholdingslipsportal/api/DownloadWithholdingSlips/download-pdf-document`;

const LICENSE_PUBLIC_KEY_B64 = "kN08rrwZddPxF2KjSIgZ0bH6veMmE94ExuEE3FbGs6s=";
const PRODUCT_ID = "coretax-toolkit";

// BUILD FLAG — true untuk trial, false untuk full
const IS_TRIAL_BUILD = true;

console.log("[DevAccTra] Extension v3.1.0 loaded. IS_TRIAL_BUILD =", IS_TRIAL_BUILD);

// ============================================================
// TRIAL GUARD — hanya aktif di trial build
// ============================================================
const TRIAL_MAX_DOWNLOADS = 10;
const TRIAL_SESSION_MS = 5 * 60 * 1000;
let trialState = { sessionStart: Date.now(), downloadCount: 0, isTrial: IS_TRIAL_BUILD };

function trialBlockReason() {
    // Bulletproof: full build TIDAK PERNAH punya limit
    if (!IS_TRIAL_BUILD) return null;
    if (!trialState.isTrial) return null;
    const elapsed = Date.now() - trialState.sessionStart;
    if (elapsed >= TRIAL_SESSION_MS) return "Sesi trial 5 menit habis. Refresh halaman Coretax untuk sesi baru.";
    if (trialState.downloadCount >= TRIAL_MAX_DOWNLOADS) return "Limit trial: maks " + TRIAL_MAX_DOWNLOADS + " PDF/sesi. Refresh untuk reset.";
    return null;
}
function trialRecordDownload() {
    if (!IS_TRIAL_BUILD) return;
    trialState.downloadCount++;
}
function trialResetSession() {
    trialState.sessionStart = Date.now();
    trialState.downloadCount = 0;
}

// ============================================================
// CRYPTO HELPERS
// ============================================================
function b64ToBytes(b64) {
    const bin = atob(b64);
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    return bytes;
}
function b64urlToBytes(str) {
    str = str.replace(/-/g, "+").replace(/_/g, "/");
    while (str.length % 4) str += "=";
    const bin = atob(str);
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    return bytes;
}
function decodePayload(licenseKey) {
    try {
        const parts = licenseKey.trim().split(".");
        if (parts.length !== 2) return null;
        return JSON.parse(new TextDecoder().decode(b64urlToBytes(parts[0])));
    } catch (e) { return null; }
}
let _publicKeyCache = null;
async function getPublicKey() {
    if (_publicKeyCache) return _publicKeyCache;
    _publicKeyCache = await crypto.subtle.importKey(
        "raw", b64ToBytes(LICENSE_PUBLIC_KEY_B64),
        { name: "Ed25519" }, false, ["verify"]
    );
    return _publicKeyCache;
}

// ============================================================
// MACHINE ID v3.1 — STABIL (clean break, no fallback)
// Formula:
//   platform + userAgentData.platform + uaData.architecture
//   + uaData.bitness + hardwareConcurrency
// Dibuang (biang MID berubah-ubah):
//   navigator.userAgent          → berubah tiap Chrome update
//   Intl timeZone                → berubah saat travel / DST
//   new Date().getTimezoneOffset → berubah saat travel / DST
//   navigator.language           → berubah saat user ganti bahasa
//   navigator.deviceMemory       → flaky / undefined di beberapa browser
// ============================================================
async function getMachineId(forceRefresh) {
    if (!forceRefresh) {
        const stored = await chrome.storage.local.get("machine_id");
        if (stored.machine_id) return stored.machine_id;
    }
    const uaData = navigator.userAgentData || {};
    const parts = [
        navigator.platform || "",
        uaData.platform || "",
        uaData.architecture || "",
        uaData.bitness || "",
        String(navigator.hardwareConcurrency || 0),
    ];
    const fp = parts.join("|");
    const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(fp));
    const hex = [...new Uint8Array(buf)].map(b => b.toString(16).padStart(2, "0")).join("");
    await chrome.storage.local.set({ machine_id: hex });
    console.log("[MachineID] v3.1 generated:", hex.substring(0, 16) + "...");
    return hex;
}

// ============================================================
// VERIFY LICENSE (single MID v3.1)
// ============================================================
async function verifyLicenseKey(licenseKey) {
    try {
        const parts = licenseKey.trim().split(".");
        if (parts.length !== 2) return { valid: false, reason: "Format license tidak valid" };
        const [payloadB64, sigB64] = parts;
        const publicKey = await getPublicKey();
        const signature = b64urlToBytes(sigB64);
        const data = new TextEncoder().encode(payloadB64);
        const ok = await crypto.subtle.verify({ name: "Ed25519" }, publicKey, signature, data);
        if (!ok) return { valid: false, reason: "License tidak sah" };

        const payload = JSON.parse(new TextDecoder().decode(b64urlToBytes(payloadB64)));

        // Scope produk
        if (payload.tools && Array.isArray(payload.tools) && payload.tools.length) {
            if (payload.tools.indexOf(PRODUCT_ID) < 0) {
                return { valid: false, reason: "License tidak include produk ini (" + payload.tools.join(", ") + ")", payload };
            }
        } else if (payload.tool && payload.tool !== PRODUCT_ID) {
            return { valid: false, reason: "License untuk produk lain: " + payload.tool, payload };
        }

        // Expired
        const today = new Date().toISOString().slice(0, 10);
        if (payload.e && payload.e < today) return { valid: false, reason: "License kadaluarsa", payload };

        // Full build: reject trial tier (pertahankan)
        if (payload.t === "trial" && !IS_TRIAL_BUILD) {
            return {
                valid: false,
                reason: "License trial TIDAK bisa dipakai di versi Pro. Download versi Trial di /dist/CoretaxPDFDownloader-Trial.zip atau lanjut pakai versi Trial.",
                payload,
                wrongBuild: true,
                wrongBuildType: "trial-in-pro"
            };
        }

        // MID check (single MID v3.1)
        const allowedMids = Array.isArray(payload.m) ? payload.m : [payload.m];
        if (allowedMids.includes("*")) return { valid: true, payload };

        const myMid = await getMachineId(false);
        if (allowedMids.includes(myMid)) return { valid: true, payload, matchedMid: myMid };

        return {
            valid: false,
            reason: "License tidak cocok dengan device ini",
            payload, allowedMids,
            currentMid: myMid,
            midMismatch: true,
        };
    } catch (e) {
        return { valid: false, reason: "Error: " + e.message };
    }
}

// ============================================================
// STRICT ACTIVATE — local Ed25519 + WAJIB ping backend
// Extension selalu online → server jadi source of truth.
// ============================================================
async function activateLicenseStrict(licenseKey) {
    // 1. Local Ed25519 verify
    const local = await verifyLicenseKey(licenseKey);
    if (!local.valid) {
        // Special: trial license dipasang di Pro build → arahin ke Trial
        return {
            success: false,
            error: local.reason,
            midMismatch: !!local.midMismatch,
            wrongBuild: !!local.wrongBuild,
            wrongBuildType: local.wrongBuildType,
            payload: local.payload,
        };
    }

    // 2. Ping backend (STRICT — extension selalu online)
    let mid;
    try { mid = await getMachineId(true); }
    catch (e) { return { success: false, error: "Gagal generate MID: " + e.message }; }

    let resp;
    try {
        resp = await fetch(API_URL + "/api/license/check", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ machine_id: mid }),
        });
    } catch (e) {
        return { success: false, error: "Tidak bisa hubungi server. Cek koneksi internet, lalu coba lagi." };
    }

    if (!resp.ok) {
        return { success: false, error: "Server error (HTTP " + resp.status + "). Coba lagi beberapa saat." };
    }

    let data;
    try { data = await resp.json(); }
    catch (e) { return { success: false, error: "Response server tidak valid." }; }

    if (!data.valid) {
        return {
            success: false,
            error: data.reason || "License tidak valid di server.",
            serverRejected: true,
            midMismatch: true,
        };
    }

    // 3. Simpan
    const finalKey = data.license_key || licenseKey.trim();
    await chrome.storage.local.set({
        license_key: finalKey,
        revoked_reason: null,
        activated_at: Date.now(),
    });

    return {
        success: true,
        payload: local.payload,
        license_key: finalKey,
        serverResigned: !!data.resigned,
        tier: data.tier || (local.payload && local.payload.t),
    };
}

// ============================================================
// SYNC LICENSE WITH BACKEND
// ============================================================
async function syncLicenseWithBackend(licenseKey) {
    try {
        const mid = await getMachineId(true);
        const resp = await fetch(API_URL + "/api/license/verify-and-resign", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ machine_id: mid, license_key: licenseKey || null }),
        });
        let data;
        try { data = await resp.json(); } catch (e) { data = { detail: "Invalid JSON" }; }
        if (!resp.ok) return { ok: false, status: resp.status, error: data.detail || "Server error" };
        return { ok: true, data };
    } catch (e) {
        return { ok: false, error: e.message };
    }
}

// ============================================================
// TRIAL AUTO-RECREATE — hanya di trial build + license tier = trial
// ============================================================
async function ensureTrialActive() {
    if (!IS_TRIAL_BUILD) return { ok: false, reason: "not_trial_build" };

    const stored = await chrome.storage.local.get("license_key");
    if (!stored.license_key) return { ok: false, reason: "no_license" };

    const payload = decodePayload(stored.license_key);
    if (!payload) return { ok: false, reason: "bad_payload" };

    // Kalau tier bukan trial (misal Pro di build Trial), SKIP recreate.
    // User tau dia lagi pakai Trial build — banner akan handle.
    if (payload.t !== "trial") {
        return { ok: true, reason: "not_trial_tier", tier: payload.t };
    }

    const mid = await getMachineId(true);
    try {
        const resp = await fetch(API_URL + "/api/trial/start", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                name: payload.n || "Trial User",
                email: payload.x || "",
                tool: payload.tool || PRODUCT_ID,
                machine_id: mid,
            }),
        });
        const data = await resp.json();
        if (data.success && data.license_key) {
            await chrome.storage.local.set({ license_key: data.license_key });
            return { ok: true, recreated: true, expires_at: data.expires_at };
        }
        if (data.suspended) {
            return { ok: true, suspended: true, reason: data.reason, until: data.until };
        }
        if (data.already_trialed && data.is_active) {
            return { ok: true, exists: true, expires_at: data.expires_at };
        }
        return { ok: false, reason: data.error || "unknown" };
    } catch (e) {
        return { ok: false, reason: e.message };
    }
}

// ============================================================
// GET LICENSE STATUS
// ============================================================
async function getLicenseStatus() {
    const stored = await chrome.storage.local.get(["license_key", "revoked_reason"]);
    const machineId = await getMachineId();

    if (stored.revoked_reason && !stored.license_key) {
        return { activated: true, valid: false, reason: stored.revoked_reason, machineId, revoked: true };
    }
    if (!stored.license_key) return { activated: false, valid: false, machineId };

    const result = await verifyLicenseKey(stored.license_key);

    if (result.valid) {
        syncLicenseWithBackend(stored.license_key).then(sync => {
            if (sync.ok && sync.data.status === "resigned" && sync.data.license_key) {
                chrome.storage.local.set({ license_key: sync.data.license_key });
            }
        }).catch(() => {});
        return {
            activated: true, valid: true,
            payload: result.payload,
            expiresAt: result.payload?.e,
            issuedAt: result.payload?.i,
            tier: result.payload?.t,
            machineId,
            isTrialBuild: IS_TRIAL_BUILD,
            isProLicenseInTrialBuild: IS_TRIAL_BUILD && result.payload?.t && result.payload.t !== "trial",
        };
    }

    // Local fail → try backend sync (resign)
    const sync = await syncLicenseWithBackend(stored.license_key);
    if (sync.ok && sync.data.status === "resigned" && sync.data.license_key) {
        await chrome.storage.local.set({ license_key: sync.data.license_key });
        const reVerify = await verifyLicenseKey(sync.data.license_key);
        if (reVerify.valid) {
            return {
                activated: true, valid: true,
                payload: reVerify.payload,
                expiresAt: reVerify.payload?.e,
                issuedAt: reVerify.payload?.i,
                tier: reVerify.payload?.t,
                machineId, autoSynced: true,
                isTrialBuild: IS_TRIAL_BUILD,
                isProLicenseInTrialBuild: IS_TRIAL_BUILD && reVerify.payload?.t && reVerify.payload.t !== "trial",
            };
        }
    }

    return {
        activated: true, valid: false,
        reason: (sync.ok && sync.data.message) ? sync.data.message : (result.reason || "License tidak valid"),
        payload: result.payload,
        expiresAt: result.payload?.e,
        tier: result.payload?.t,
        machineId, syncTried: true,
        isTrialBuild: IS_TRIAL_BUILD,
    };
}

// ============================================================
// STATE CAPTURE
// ============================================================
let latestAuth = { authorization: null, xDgtCode: null };
const captured = { input: null, output: null, withholding: null };
const downloadState = { running: false, stopRequested: false, total: 0, completed: 0, failed: 0, current: null, results: [] };

function getActiveInvoiceMode() {
    const inp = captured.input, out = captured.output;
    if (!inp && !out) return null;
    if (!inp) return "output";
    if (!out) return "input";
    return inp.capturedAt > out.capturedAt ? "input" : "output";
}
function headerValue(headers, name) {
    if (!headers) return null;
    const t = name.toLowerCase();
    const f = headers.find(h => h.name && h.name.toLowerCase() === t);
    return f ? f.value : null;
}
function parseRequestBody(rb) {
    if (!rb || !rb.raw) return null;
    try {
        const chunks = rb.raw.map(i => i.bytes).filter(Boolean);
        if (!chunks.length) return null;
        const combined = new Uint8Array(chunks.reduce((t, c) => t + c.byteLength, 0));
        let off = 0;
        for (const ch of chunks) { const b = new Uint8Array(ch); combined.set(b, off); off += b.length; }
        return new TextDecoder("utf-8").decode(combined);
    } catch (e) { return null; }
}
function clone(v) { return structuredClone(v); }
function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }
function normalizeDocumentDate(v) {
    if (!v) return null;
    return String(v).replace("Z", "").replace(/[+-]\d{2}:\d{2}$/, "");
}
function sanitizeFilename(name, fallback) {
    if (!name) return fallback || "coretax.pdf";
    let f = String(name).replace(/[<>:"/\\|?*\x00-\x1F]/g, "_").trim();
    if (!f.toLowerCase().endsWith(".pdf")) f += ".pdf";
    return f;
}

chrome.webRequest.onBeforeSendHeaders.addListener(
    details => {
        if (!details.url.startsWith(CORE_URL)) return;
        const auth = headerValue(details.requestHeaders, "authorization");
        const xDgt = headerValue(details.requestHeaders, "x-dgt-code");
        if (auth) latestAuth.authorization = auth;
        if (xDgt) latestAuth.xDgtCode = xDgt;
    },
    { urls: [`${CORE_URL}/*`] },
    ["requestHeaders", "extraHeaders"]
);

chrome.webRequest.onBeforeRequest.addListener(
    details => {
        if (details.method !== "POST") return;
        const url = details.url;
        let kind = null;
        if (url === INPUT_LIST_URL) kind = "input";
        else if (url === OUTPUT_LIST_URL) kind = "output";
        else if (url === WITHHOLDING_LIST_URL) kind = "withholding";
        else return;
        const body = parseRequestBody(details.requestBody);
        if (!body) return;
        try { captured[kind] = { payload: JSON.parse(body), capturedAt: Date.now(), tabId: details.tabId }; }
        catch (e) {}
    },
    { urls: [INPUT_LIST_URL, OUTPUT_LIST_URL, WITHHOLDING_LIST_URL] },
    ["requestBody"]
);

async function coretaxFetch(url, body) {
    const headers = { "Accept": "application/json, text/plain, */*", "Content-Type": "application/json" };
    if (latestAuth.authorization) headers["Authorization"] = latestAuth.authorization;
    if (latestAuth.xDgtCode) headers["x-dgt-code"] = latestAuth.xDgtCode;
    const response = await fetch(url, { method: "POST", headers, body: JSON.stringify(body), credentials: "include" });
    const text = await response.text();
    let json;
    try { json = JSON.parse(text); } catch { throw new Error(`Coretax return non-JSON (HTTP ${response.status})`); }
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    if (json && json.IsSuccessful === false) throw new Error(json.Message || json.ErrorMessage || "Coretax request gagal");
    return json;
}

async function getInvoiceList(mode, customPayload = null) {
    const cap = captured[mode];
    if (!customPayload && !cap) throw new Error(`Belum ada request Faktur ${mode === "input" ? "Masukan" : "Keluaran"}. Refresh halaman list-nya dulu.`);
    const payload = customPayload ? clone(customPayload) : clone(cap.payload);
    const url = mode === "output" ? OUTPUT_LIST_URL : INPUT_LIST_URL;
    return await coretaxFetch(url, payload);
}
async function getWithholdingList(customPayload = null) {
    if (!customPayload && !captured.withholding) throw new Error("Belum ada request Bukti Potong. Refresh halaman My Withholding Slips dulu.");
    const payload = customPayload ? clone(customPayload) : clone(captured.withholding.payload);
    return await coretaxFetch(WITHHOLDING_LIST_URL, payload);
}

function buildInvoiceDownloadPayload(row, mode) {
    if (mode === "output") {
        return {
            DocumentAggregateIdentifier: row.DocumentFormAggregateIdentifier,
            DocumentDate: normalizeDocumentDate(row.LastUpdatedDate) || normalizeDocumentDate(row.TaxInvoiceDate),
            EInvoiceAggregateIdentifier: row.AggregateIdentifier,
            EInvoiceMenuType: "Outgoing",
            EInvoiceRecordIdentifier: row.RecordId,
            LetterNumber: row.TaxInvoiceNumber,
            TaxInvoiceStatus: row.TaxInvoiceStatus,
            TaxpayerAggregateIdentifier: row.SellerTaxpayerAggregateIdentifier
        };
    }
    return {
        EInvoiceRecordIdentifier: row.RecordId,
        EInvoiceAggregateIdentifier: row.AggregateIdentifier,
        DocumentAggregateIdentifier: row.DocumentFormAggregateIdentifier,
        TaxpayerAggregateIdentifier: row.BuyerTaxpayerAggregateIdentifier,
        LetterNumber: row.TaxInvoiceNumber,
        DocumentDate: normalizeDocumentDate(row.LastUpdatedDate) || normalizeDocumentDate(row.TaxInvoiceDate),
        EInvoiceMenuType: "Input",
        TaxInvoiceStatus: row.TaxInvoiceStatus
    };
}
function buildWithholdingDownloadPayload(row) {
    return {
        WithholdingSlipsAggregateIdentifier: row.WithholdingslipsAggregateIdentifier,
        WithholdingSlipsRecordIdentifier: row.RecordId,
        DocumentAggregateIdentifier: row.DocumentFormAggregateIdentifier,
        TaxpayerAggregateIdentifier: row.TaxpayerAggregateIdentifier,
        EbupotType: row.__EbupotType || captured.withholding?.payload?.WithholdingType || "EBUPOTBPU",
        DocumentDate: normalizeDocumentDate(row.LastUpdatedDate) || normalizeDocumentDate(row.CreationDate) || normalizeDocumentDate(row.WithholdingSlipsDate),
        TaxIdentificationNumber: row.TaxIdentificationNumber
    };
}

async function downloadInvoice(row, mode) {
    trialRecordDownload();
    const result = await coretaxFetch(INVOICE_DOWNLOAD_URL, buildInvoiceDownloadPayload(row, mode));
    const message = result?.Payload?.Message || null;
    const data = message?.Data || result?.Content || null;
    if (!message && !result.Content) throw new Error("Response tidak ada PDF.");
    if (message && message.IsSuccessful === false) throw new Error(message.ErrorMessage || result.Message || "Coretax gagal buat PDF.");
    if (!data) throw new Error("Data Base64 PDF tidak ditemukan.");
    const filename = sanitizeFilename(message?.FileName || result?.FileName, `Coretax_${row.TaxInvoiceNumber || row.RecordId}.pdf`);
    await chrome.downloads.download({ url: `data:application/pdf;base64,${data}`, filename, saveAs: false, conflictAction: "uniquify" });
    return { success: true, filename, invoiceNumber: row.TaxInvoiceNumber };
}
async function downloadWithholding(row) {
    trialRecordDownload();
    const result = await coretaxFetch(WITHHOLDING_DOWNLOAD_URL, buildWithholdingDownloadPayload(row));
    const message = result?.Payload?.Message || null;
    if (!message && !result?.Content) throw new Error("Response tidak ada PDF.");
    if (message && message.IsSuccessful === false) throw new Error(message.ErrorMessage || result.Message || "Coretax gagal buat PDF.");
    const base64 = message?.Data || result?.Content || null;
    if (!base64) throw new Error("Data Base64 PDF tidak ditemukan.");
    const filename = sanitizeFilename(message?.FileName || result?.FileName, `Coretax_${row.WithholdingSlipsNumber || row.RecordId}.pdf`);
    await chrome.downloads.download({ url: `data:application/pdf;base64,${base64}`, filename, saveAs: false, conflictAction: "uniquify" });
    return { success: true, filename, withholdingNumber: row.WithholdingSlipsNumber, recordId: row.RecordId };
}

async function downloadAll(kind, rows) {
    if (downloadState.running) throw new Error("Download All sedang berjalan.");
    downloadState.running = true;
    downloadState.stopRequested = false;
    downloadState.total = rows.length;
    downloadState.completed = 0;
    downloadState.failed = 0;
    downloadState.current = null;
    downloadState.results = [];
    try {
        for (let i = 0; i < rows.length; i++) {
            if (downloadState.stopRequested) break;
            const row = rows[i];
            downloadState.current = { index: i + 1, invoiceNumber: row.TaxInvoiceNumber || row.WithholdingSlipsNumber || "-" };
            let success = false, lastError = null;
            for (let attempt = 1; attempt <= 2; attempt++) {
                try {
                    const result = kind === "withholding" ? await downloadWithholding(row) : await downloadInvoice(row, kind);
                    downloadState.completed++;
                    downloadState.results.push({ ...result, status: "success" });
                    success = true;
                    break;
                } catch (error) {
                    lastError = error;
                    if (attempt < 2) await sleep(1200);
                }
            }
            if (!success) {
                downloadState.failed++;
                downloadState.results.push({ invoiceNumber: row.TaxInvoiceNumber || row.WithholdingSlipsNumber || "-", status: "failed", error: lastError?.message || "Unknown error" });
            }
            await sleep(300);
        }
    } finally {
        downloadState.running = false;
        downloadState.current = null;
    }
    return clone(downloadState);
}

async function getAllInvoice(mode) {
    const cap = captured[mode];
    if (!cap) throw new Error("Belum ada request list.");
    const base = clone(cap.payload);
    let rowsPerPage = Number(base.Rows) || 10;
    let first = Number(base.First || 0);
    const firstResp = await getInvoiceList(mode, { ...clone(base), First: first, Rows: rowsPerPage });
    const firstData = firstResp?.Payload?.Data || [];
    const total = Number(firstResp?.Payload?.TotalRecords || firstData.length);
    const all = [...firstData];
    const totalPages = Math.ceil(total / rowsPerPage);
    for (let page = 1; page < totalPages; page++) {
        const payload = clone(base);
        payload.First = first + page * rowsPerPage;
        payload.Rows = rowsPerPage;
        const resp = await getInvoiceList(mode, payload);
        const data = resp?.Payload?.Data || [];
        if (!data.length) break;
        all.push(...data);
    }
    return { rows: all, totalRecords: total, rowsPerPage };
}
async function getAllWithholding() {
    if (!captured.withholding) throw new Error("Belum ada request Bukti Potong.");
    const base = clone(captured.withholding.payload);
    let rowsPerPage = Number(base.Rows) || 10;
    let first = Number(base.First || 0);
    const firstResp = await getWithholdingList({ ...clone(base), First: first, Rows: rowsPerPage });
    const firstData = firstResp?.Payload?.Data || [];
    const total = Number(firstResp?.Payload?.TotalRecords || firstData.length);
    firstData.forEach(row => { row.__EbupotType = base.WithholdingType || "EBUPOTBPU"; });
    const all = [...firstData];
    const totalPages = Math.ceil(total / rowsPerPage);
    for (let page = 1; page < totalPages; page++) {
        const payload = clone(base);
        payload.First = first + page * rowsPerPage;
        payload.Rows = rowsPerPage;
        const resp = await getWithholdingList(payload);
        const data = resp?.Payload?.Data || [];
        if (!data.length) break;
        data.forEach(row => { row.__EbupotType = base.WithholdingType || "EBUPOTBPU"; });
        all.push(...data);
    }
    return { rows: all, totalRecords: total, rowsPerPage };
}

// ============================================================
// MESSAGE HANDLERS
// ============================================================
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === "GET_LICENSE_STATUS") { getLicenseStatus().then(sendResponse); return true; }
    if (message.type === "GET_MACHINE_ID") { getMachineId().then(id => sendResponse({ machineId: id })); return true; }
    if (message.type === "GET_BUILD_INFO") {
        sendResponse({ isTrialBuild: IS_TRIAL_BUILD, version: "3.1.0", productId: PRODUCT_ID });
        return true;
    }
    if (message.type === "ACTIVATE_LICENSE") {
        (async () => { sendResponse(await activateLicenseStrict(message.licenseKey)); })();
        return true;
    }
    if (message.type === "REBIND_LICENSE") {
        (async () => {
            try {
                const resp = await fetch(API_URL + "/api/license/rebind", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({
                        license_key: message.license_key,
                        old_machine_id: message.old_machine_id,
                        new_machine_id: message.new_machine_id,
                    }),
                });
                let data;
                try { data = await resp.json(); } catch (e) { data = { detail: "Invalid JSON" }; }
                if (!resp.ok) { sendResponse({ success: false, error: data.detail || ("HTTP " + resp.status) }); return; }
                if (data.license_key) await chrome.storage.local.set({ license_key: data.license_key });
                sendResponse({ success: true, data });
            } catch (e) { sendResponse({ success: false, error: e.message }); }
        })();
        return true;
    }
    if (message.type === "CHECK_LICENSE_NOW") {
        (async () => { sendResponse(await checkLicenseFresh(true)); })();
        return true;
    }
    if (message.type === "SYNC_LICENSE_WITH_BACKEND") {
        (async () => {
            const stored = await chrome.storage.local.get("license_key");
            if (!stored.license_key) { sendResponse({ success: false, error: "Belum ada license." }); return; }
            const sync = await syncLicenseWithBackend(stored.license_key);
            if (sync.ok && sync.data.status === "resigned" && sync.data.license_key) {
                await chrome.storage.local.set({ license_key: sync.data.license_key });
            }
            const check = await checkLicenseFresh(true);
            if (check && check.valid === false) { sendResponse({ success: false, error: check.reason, revoked: true }); return; }
            if (check && check.network_error) { sendResponse({ success: true, status: "network_error", message: "Server tidak terjangkau." }); return; }
            sendResponse({ success: true, status: "ok", message: "License valid." });
        })();
        return true;
    }
    if (message.type === "ENSURE_TRIAL_ACTIVE") {
        ensureTrialActive().then(sendResponse);
        return true;
    }
    if (message.type === "RESET_MACHINE_ID") {
        (async () => {
            await chrome.storage.local.remove("machine_id");
            const fresh = await getMachineId(true);
            sendResponse({ success: true, machineId: fresh });
        })();
        return true;
    }
    if (message.type === "RESET_LICENSE") {
        (async () => { await chrome.storage.local.remove(["license_key", "revoked_reason"]); sendResponse({ success: true }); })();
        return true;
    }
    if (message.type === "RESET_TRIAL_SESSION") {
        trialResetSession();
        sendResponse({ success: true, remaining: TRIAL_MAX_DOWNLOADS });
        return true;
    }
    if (message.type === "GET_TRIAL_STATE") {
        const elapsed = Date.now() - trialState.sessionStart;
        sendResponse({
            isTrial: trialState.isTrial,
            remainingMs: Math.max(0, TRIAL_SESSION_MS - elapsed),
            remainingDownloads: Math.max(0, TRIAL_MAX_DOWNLOADS - trialState.downloadCount),
            blocked: !!trialBlockReason(),
            blockReason: trialBlockReason(),
            buildIsTrial: IS_TRIAL_BUILD,
        });
        return true;
    }
    if (message.type === "GET_STATUS") {
        sendResponse({
            success: true,
            authCaptured: !!latestAuth.authorization,
            xDgtCaptured: !!latestAuth.xDgtCode,
            hasInput: !!captured.input,
            hasOutput: !!captured.output,
            hasWithholding: !!captured.withholding,
            activeInvoiceMode: getActiveInvoiceMode(),
            downloadState: clone(downloadState),
        });
        return true;
    }
    if (message.type === "GET_INVOICE_LIST") {
        const mode = getActiveInvoiceMode();
        if (!mode) { sendResponse({ success: false, error: "Belum ada request Faktur Pajak." }); return true; }
        getInvoiceList(mode).then(r => sendResponse({ success: true, data: r, mode })).catch(e => sendResponse({ success: false, error: e.message }));
        return true;
    }
    if (message.type === "GET_INVOICE_ALL") {
        const mode = getActiveInvoiceMode();
        if (!mode) { sendResponse({ success: false, error: "Belum ada request Faktur Pajak." }); return true; }
        getAllInvoice(mode).then(r => sendResponse({ success: true, ...r, mode })).catch(e => sendResponse({ success: false, error: e.message }));
        return true;
    }
    if (message.type === "GET_WITHHOLDING_LIST") {
        getWithholdingList().then(r => sendResponse({ success: true, data: r })).catch(e => sendResponse({ success: false, error: e.message }));
        return true;
    }
    if (message.type === "GET_WITHHOLDING_ALL") {
        getAllWithholding().then(r => sendResponse({ success: true, ...r })).catch(e => sendResponse({ success: false, error: e.message }));
        return true;
    }
    if (message.type === "DOWNLOAD_INVOICE_ONE") {
        const tr = trialBlockReason();
        if (tr) { sendResponse({ success: false, error: tr }); return true; }
        const mode = getActiveInvoiceMode();
        if (!mode) { sendResponse({ success: false, error: "Mode tidak diketahui." }); return true; }
        downloadInvoice(message.row, mode).then(r => sendResponse({ success: true, result: r })).catch(e => sendResponse({ success: false, error: e.message }));
        return true;
    }
    if (message.type === "DOWNLOAD_WITHHOLDING_ONE") {
        const tr = trialBlockReason();
        if (tr) { sendResponse({ success: false, error: tr }); return true; }
        downloadWithholding(message.row).then(r => sendResponse({ success: true, result: r })).catch(e => sendResponse({ success: false, error: e.message }));
        return true;
    }
    if (message.type === "DOWNLOAD_INVOICE_ALL") {
        // BULLETPROOF: hanya trial build yang punya cap
        if (!IS_TRIAL_BUILD) {
            const mode = getActiveInvoiceMode();
            if (!mode) { sendResponse({ success: false, error: "Mode tidak diketahui." }); return true; }
            downloadAll(mode, message.rows).then(r => sendResponse({ success: true, result: r })).catch(e => sendResponse({ success: false, error: e.message }));
            return true;
        }
        const remaining = TRIAL_MAX_DOWNLOADS - trialState.downloadCount;
        if (remaining <= 0) { sendResponse({ success: false, error: "Limit trial habis. Refresh halaman Coretax." }); return true; }
        const capped = (message.rows || []).slice(0, remaining);
        downloadAll("output", capped).then(r => sendResponse({ success: true, result: r, capped: true })).catch(e => sendResponse({ success: false, error: e.message }));
        return true;
    }
    if (message.type === "DOWNLOAD_WITHHOLDING_ALL") {
        if (!IS_TRIAL_BUILD) {
            downloadAll("withholding", message.rows).then(r => sendResponse({ success: true, result: r })).catch(e => sendResponse({ success: false, error: e.message }));
            return true;
        }
        const remaining = TRIAL_MAX_DOWNLOADS - trialState.downloadCount;
        if (remaining <= 0) { sendResponse({ success: false, error: "Limit trial habis. Refresh halaman Coretax." }); return true; }
        const capped = (message.rows || []).slice(0, remaining);
        downloadAll("withholding", capped).then(r => sendResponse({ success: true, result: r, capped: true })).catch(e => sendResponse({ success: false, error: e.message }));
        return true;
    }
    if (message.type === "STOP_DOWNLOAD") {
        downloadState.stopRequested = true;
        sendResponse({ success: true });
        return true;
    }
});

// ============================================================
// INSTALL
// ============================================================
chrome.runtime.onInstalled.addListener((details) => {
    if (details.reason === "install") {
        chrome.tabs.create({ url: chrome.runtime.getURL("src/welcome.html") });
    }
});

// ============================================================
// PERIODIC LICENSE CHECK (revoke detection)
// ============================================================
const REVOKE_CHECK_INTERVAL_MS = 6 * 60 * 60 * 1000;
const STORAGE_LAST_CHECK = "last_check_ms";
const STORAGE_REVOKED_REASON = "revoked_reason";

async function checkLicenseFresh(force) {
    const stored = await chrome.storage.local.get(["license_key", STORAGE_LAST_CHECK]);
    if (!stored.license_key) return { valid: false, reason: "Belum ada license", code: "no_license" };

    const now = Date.now();
    const last = stored[STORAGE_LAST_CHECK] || 0;
    if (!force && now - last < REVOKE_CHECK_INTERVAL_MS) return { valid: true, cached: true };

    try {
        const mid = await getMachineId(true);
        const resp = await fetch(API_URL + "/api/license/check", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ machine_id: mid }),
        });
        if (!resp.ok) return { valid: true, network_error: true, reason: "Server " + resp.status };
        const data = await resp.json();

        if (!data.valid) {
            await chrome.storage.local.remove("license_key");
            await chrome.storage.local.set({ [STORAGE_REVOKED_REASON]: data.reason });
            chrome.tabs.query({}, (tabs) => {
                tabs.forEach(t => { if (t.id) chrome.tabs.sendMessage(t.id, { type: "LICENSE_REVOKED", reason: data.reason }).catch(() => {}); });
            });
            return { valid: false, reason: data.reason };
        }

        if (data.license_key && data.resigned) {
            await chrome.storage.local.set({ license_key: data.license_key });
        }

        await chrome.storage.local.set({ [STORAGE_LAST_CHECK]: now, [STORAGE_REVOKED_REASON]: null });
        return { valid: true, license_key: data.license_key };
    } catch (e) {
        // Network error → percaya verify lokal (offline-friendly setelah aktivasi sukses)
        return { valid: true, network_error: true, reason: e.message };
    }
}

const ALARM_NAME = "license-check";
function ensureAlarm() {
    chrome.alarms.get(ALARM_NAME, (alarm) => {
        if (!alarm) chrome.alarms.create(ALARM_NAME, { delayInMinutes: 1, periodInMinutes: 360 });
    });
}
chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === ALARM_NAME) checkLicenseFresh(true).catch(() => {});
});
ensureAlarm();
setTimeout(() => { checkLicenseFresh(false).catch(() => {}); }, 2000);

// ============================================================
// WELCOME PAGE: generate trial via backend
// ============================================================
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === "GENERATE_TRIAL_LICENSE") {
        (async () => {
            try {
                const resp = await fetch(API_URL + "/api/trial/start", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify(message.payload),
                });
                const data = await resp.json();
                sendResponse({ ok: resp.ok, status: resp.status, data });
            } catch (e) {
                sendResponse({ ok: false, error: e.message || "Network error" });
            }
        })();
        return true;
    }
});