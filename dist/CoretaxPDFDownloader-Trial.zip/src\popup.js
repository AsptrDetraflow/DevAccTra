﻿const licenseSection = document.getElementById("license-section");
const activeSection = document.getElementById("active-section");
const machineIdEl = document.getElementById("machine-id");
const licenseInput = document.getElementById("license-input");
const licenseMessage = document.getElementById("license-message");
const licenseInfo = document.getElementById("license-info");
const statusAuth = document.getElementById("status-auth");
const hdr = document.getElementById("hdr");
const hdrTitle = document.getElementById("hdrTitle");
const hdrSub = document.getElementById("hdrSub");
const actBtn = document.getElementById("activate");
const syncWrap = document.getElementById("syncWrap");
const trialInfoEl = document.getElementById("trial-info");
const proInTrialBox = document.getElementById("pro-in-trial-box");

function send(m) { return new Promise(r => chrome.runtime.sendMessage(m, r)); }

let BUILD = { isTrialBuild: true, version: "3.1.0" };

function applyTheme() {
    if (BUILD.isTrialBuild) {
        hdr.classList.remove("full"); hdr.classList.add("trial");
        actBtn.classList.remove("full"); actBtn.classList.add("trial");
        hdrTitle.innerHTML = 'Coretax PDF Downloader<span class="badge">UNOFFICIAL</span><span class="tag trial">TRIAL</span>';
        hdrSub.textContent = 'Trial \u00B7 maks 10 PDF / 5 menit';
    } else {
        hdr.classList.remove("trial"); hdr.classList.add("full");
        actBtn.classList.remove("trial"); actBtn.classList.add("full");
        hdrTitle.innerHTML = 'Coretax PDF Downloader<span class="badge">UNOFFICIAL</span><span class="tag pro">PRO</span>';
        hdrSub.textContent = 'Pro \u00B7 Unlimited';
        const s = document.getElementById("syncBtn"); if (s) s.classList.add("full");
        const sa = document.getElementById("syncBtnActive"); if (sa) sa.classList.add("full");
    }
}

async function init() {
    try { BUILD = await send({ type: "GET_BUILD_INFO" }) || BUILD; } catch (e) {}
    applyTheme();

    const status = await send({ type: "GET_LICENSE_STATUS" });
    machineIdEl.textContent = status.machineId;

    if (status.activated && status.valid) {
        licenseSection.classList.add("hidden");
        activeSection.classList.remove("hidden");
        licenseInfo.innerHTML = 'Expired: <b>' + (status.expiresAt || "-") + '</b><br>Tier: <b>' + (status.tier || "pro") + '</b>';

        const isProLicenseInTrial = status.isProLicenseInTrialBuild;
        const scope = document.getElementById("license-scope");

        if (!BUILD.isTrialBuild && status.tier === "trial") {
            // PRO build + trial license → tampil error merah, jangan info biru
            if (scope) {
                scope.innerHTML = '\u26A0 License trial TIDAK bisa dipakai di versi Pro.';
                scope.style.background = "rgba(220,38,38,.1)";
                scope.style.color = "#991B1B";
                scope.style.fontWeight = "700";
            }
            if (proInTrialBox) proInTrialBox.classList.add("hidden");
            if (trialInfoEl) {
                trialInfoEl.classList.remove("hidden");
                trialInfoEl.innerHTML = '<b>\u26A0 License trial ditolak</b><br>Kamu pakai <b>versi Pro</b>, tapi license yang kepasang <b>trial</b>. Download versi Trial untuk pakai license ini, atau beli license Pro.' +
                    '<br><a href="https://asptrdetraflow.github.io/DevAccTra/dist/CoretaxPDFDownloader-Trial.zip" target="_blank" style="display:inline-block;margin-top:8px;padding:8px 14px;background:#004D2F;color:#fff;border-radius:6px;text-decoration:none;font-weight:800;font-size:10.5px;">\u2B07 Download Versi Trial</a>';
                trialInfoEl.style.background = "linear-gradient(135deg,rgba(220,38,38,.08),rgba(220,38,38,.02))";
                trialInfoEl.style.borderColor = "rgba(220,38,38,.3)";
                trialInfoEl.style.color = "#991B1B";
            }
            licenseInfo.innerHTML = '<span style="color:#991B1B;font-weight:700">License trial TIDAK valid di versi Pro</span>';
        } else if (status.tier === "trial") {
            if (scope) {
                scope.innerHTML = 'TRIAL \u00B7 maks 10 PDF / sesi 5 menit';
                scope.style.background = "rgba(245,158,11,.1)";
                scope.style.color = "#92400E";
            }
            if (proInTrialBox) proInTrialBox.classList.add("hidden");
        } else if (isProLicenseInTrial) {
            // PRO LICENSE di TRIAL BUILD → user HARUS TAU
            if (scope) {
                scope.innerHTML = '\u26A0 VERSI TRIAL \u00B7 meskipun license PRO, tetap kena limit 10 PDF / 5 menit';
                scope.style.background = "rgba(30,91,184,.12)";
                scope.style.color = "#1E5BB8";
                scope.style.fontWeight = "700";
            }
            if (proInTrialBox) {
                proInTrialBox.classList.remove("hidden");
                proInTrialBox.innerHTML =
                    '<b>\u26A0 Kamu pakai VERSI TRIAL</b>' +
                    'License kamu <b>PRO</b>, tapi extension yang kepasang adalah <b>versi TRIAL</b>. Limit tetap 10 PDF / 5 menit. Download versi Pro untuk unlimited.' +
                    '<br><a href="https://asptrdetraflow.github.io/DevAccTra/dist/CoretaxPDFDownloader-Pro.zip" target="_blank">\u2B07 Download Versi Pro</a>';
            }
        } else {
            // Full build + license pro
            if (scope) {
                scope.innerHTML = 'PRO \u00B7 unlimited';
                scope.style.background = "rgba(0,77,47,.08)";
                scope.style.color = "#004D2F";
            }
            if (proInTrialBox) proInTrialBox.classList.add("hidden");
        }

        await refreshStatus();
    } else {
        licenseSection.classList.remove("hidden");
        activeSection.classList.add("hidden");
        if (status.activated && !status.valid) {
            licenseMessage.innerHTML = '<span class="bad">License tidak valid: ' + status.reason + '</span>';
        }
        if (BUILD.isTrialBuild && trialInfoEl) {
            trialInfoEl.classList.remove("hidden");
            trialInfoEl.innerHTML = '<b>Versi Trial</b> \u00B7 Maks 10 PDF per sesi, sesi 5 menit. Untuk unlimited, upgrade ke Pro.';
        }
        if (proInTrialBox) proInTrialBox.classList.add("hidden");
    }
}

async function refreshStatus() {
    const check = await send({ type: "CHECK_LICENSE_NOW" });
    if (check && check.valid === false) {
        licenseSection.classList.remove("hidden");
        activeSection.classList.add("hidden");
        licenseMessage.innerHTML = '<span class="bad">License tidak valid: ' + (check.reason || "invalid") + '</span>';
        return;
    }
    const status = await send({ type: "GET_STATUS" });
    if (!status.success) return;
    const lines = [];
    lines.push(status.authCaptured ? '<span class="ok">\u2713</span> Authorization tertangkap' : '<span class="bad">\u2717</span> Authorization belum');
    lines.push(status.xDgtCaptured ? '<span class="ok">\u2713</span> x-dgt-code tertangkap' : '<span class="bad">\u2717</span> x-dgt-code belum');
    const hasAny = status.hasInput || status.hasOutput || status.hasWithholding;
    lines.push(hasAny ? '<span class="ok">\u2713</span> Data list tertangkap' : '<span class="bad">\u2717</span> Belum ada list');
    statusAuth.innerHTML = lines.join("<br>");
}

if (licenseInput) {
    licenseInput.addEventListener("input", function() {
        if (syncWrap) syncWrap.classList.toggle("hidden", !licenseInput.value.trim());
    });
}

document.getElementById("copy-machine").addEventListener("click", async () => {
    await navigator.clipboard.writeText(machineIdEl.textContent);
    const btn = document.getElementById("copy-machine");
    btn.textContent = "\u2713 Copied";
    setTimeout(() => btn.textContent = "Copy Machine ID", 1500);
});

document.getElementById("activate").addEventListener("click", async () => {
    const key = licenseInput.value.trim();
    if (!key) { licenseMessage.innerHTML = '<span class="bad">License kosong.</span>'; return; }
    licenseMessage.innerHTML = '<span>Memverifikasi (butuh internet)...</span>';
    const result = await send({ type: "ACTIVATE_LICENSE", licenseKey: key });

    if (result.success) {
        licenseMessage.innerHTML = '<span class="ok">\u2713 License berhasil' + (result.serverResigned ? ' (auto-resign)' : '') + '</span>';
        setTimeout(init, 700);
        return;
    }

    // Wrong build: trial license di Pro build
    if (result.wrongBuild) {
        licenseMessage.innerHTML = '<span class="bad">\u2717 ' + result.error + '</span>';
        return;
    }

    licenseMessage.innerHTML = '<span class="bad">\u2717 ' + result.error + '</span>';
    if (result.midMismatch) {
        const mid = (await send({ type: "GET_MACHINE_ID" })).machineId || "";
        showRebindModal(mid, key, "License ini untuk device lain. Masukkan MID device lama untuk sinkronisasi.");
    }
});

async function doSync() {
    const btns = [document.getElementById("syncBtn"), document.getElementById("syncBtnActive")].filter(b => b);
    btns.forEach(b => { b.disabled = true; b.textContent = "Syncing..."; });
    try {
        const ta = document.getElementById("license-input");
        if (ta && ta.value.trim()) {
            const current = await send({ type: "GET_LICENSE_STATUS" });
            if (!current.activated || !current.payload) {
                const act = await send({ type: "ACTIVATE_LICENSE", licenseKey: ta.value.trim() });
                if (!act.success && act.midMismatch) {
                    const mid = (await send({ type: "GET_MACHINE_ID" })).machineId || "";
                    showRebindModal(mid, ta.value.trim(), "License untuk device lain.");
                    return;
                }
                if (act.success) { licenseMessage.innerHTML = '<span class="ok">\u2713 License tersimpan.</span>'; setTimeout(init, 600); return; }
                licenseMessage.innerHTML = '<span class="bad">\u2717 ' + act.error + '</span>';
                return;
            }
        }
        const res = await send({ type: "SYNC_LICENSE_WITH_BACKEND" });
        if (res && res.success) {
            licenseMessage.innerHTML = '<span class="ok">\u2713 ' + (res.message || "Sync berhasil") + '</span>';
            setTimeout(init, 600);
        } else {
            const err = (res && res.error) || "Sync gagal";
            licenseMessage.innerHTML = '<span class="bad">\u2717 ' + err + '</span>';
            if (isMismatchError(err)) {
                const mid = (await send({ type: "GET_MACHINE_ID" })).machineId || "";
                const ta2 = document.getElementById("license-input");
                showRebindModal(mid, ta2 ? ta2.value.trim() : "", "License untuk device lain.");
            }
        }
    } finally {
        btns.forEach(b => { b.disabled = false; b.textContent = "Sync"; });
    }
}
const _sb = document.getElementById("syncBtn"); if (_sb) _sb.addEventListener("click", doSync);
const _sba = document.getElementById("syncBtnActive"); if (_sba) _sba.addEventListener("click", doSync);

document.getElementById("refresh-status").addEventListener("click", refreshStatus);
document.getElementById("reset-license").addEventListener("click", async () => {
    if (!confirm("Reset license?")) return;
    await send({ type: "RESET_LICENSE" });
    setTimeout(init, 300);
});

function showRebindModal(currentMid, prefilledKey, errorMsg) {
    const modal = document.getElementById("rebindModal");
    if (!modal) return;
    document.getElementById("rebindCurrentMid").textContent = currentMid || "-";
    document.getElementById("rebindOldMid").value = "";
    const errEl = document.getElementById("rebindErr");
    errEl.style.display = "none";
    if (errorMsg) { errEl.textContent = errorMsg; errEl.style.display = "block"; }
    modal.style.display = "flex";
    setTimeout(() => document.getElementById("rebindOldMid").focus(), 150);

    document.getElementById("rebindCancel").onclick = () => { modal.style.display = "none"; };
    document.getElementById("rebindConfirm").onclick = async () => {
        const oldMid = document.getElementById("rebindOldMid").value.trim();
        errEl.style.display = "none";
        if (!/^[a-f0-9]{64}$/.test(oldMid)) { errEl.textContent = "MID harus 64 karakter hex."; errEl.style.display = "block"; return; }
        if (oldMid === currentMid) { errEl.textContent = "MID lama sama dengan device ini."; errEl.style.display = "block"; return; }

        let license = prefilledKey || "";
        if (!license) { const ta = document.getElementById("license-input"); license = ta ? ta.value.trim() : ""; }
        if (!license) { errEl.textContent = "Belum ada license. Paste dulu."; errEl.style.display = "block"; return; }

        const btn = document.getElementById("rebindConfirm");
        btn.disabled = true; btn.textContent = "Memproses...";
        try {
            const res = await send({ type: "REBIND_LICENSE", license_key: license, old_machine_id: oldMid, new_machine_id: currentMid });
            if (res && res.success) {
                btn.textContent = "Berhasil!";
                setTimeout(() => { modal.style.display = "none"; init(); }, 600);
            } else {
                errEl.textContent = (res && res.error) || "Gagal sinkron.";
                errEl.style.display = "block";
                btn.disabled = false; btn.textContent = "Sinkronkan";
            }
        } catch (e) {
            errEl.textContent = "Error: " + e.message;
            errEl.style.display = "block";
            btn.disabled = false; btn.textContent = "Sinkronkan";
        }
    };
}

function isMismatchError(msg) {
    if (!msg) return false;
    const m = msg.toLowerCase();
    return m.includes("device") || m.includes("cocok") || m.includes("lain") || m.includes("mid") || m.includes("terdaftar");
}

init();

// ============================================================
(function() {
    const btn = document.getElementById("claimTrialBtn");
    if (!btn) return;
    const modal = document.getElementById("claimTrialModal");
    const emailInput = document.getElementById("claimEmail");
    const errEl = document.getElementById("claimErr");
    const okEl = document.getElementById("claimOk");
    const submitBtn = document.getElementById("claimSubmitBtn");
    const cancelBtn = document.getElementById("claimCancelBtn");

    function openModal() {
        if (!modal) return;
        modal.style.display = "flex";
        errEl.style.display = "none";
        okEl.style.display = "none";
        emailInput.value = "";
        setTimeout(() => emailInput.focus(), 100);
    }
    function closeModal() {
        if (modal) modal.style.display = "none";
    }

    btn.addEventListener("click", openModal);
    if (cancelBtn) cancelBtn.addEventListener("click", closeModal);
    if (modal) modal.addEventListener("click", (e) => { if (e.target === modal) closeModal(); });
    if (emailInput) emailInput.addEventListener("keydown", (e) => { if (e.key === "Enter") doClaim(); });
    if (submitBtn) submitBtn.addEventListener("click", doClaim);

    async function doClaim() {
        const email = (emailInput.value || "").trim().toLowerCase();
        errEl.style.display = "none";
        okEl.style.display = "none";

        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
            errEl.textContent = "Format email tidak valid.";
            errEl.style.display = "block";
            return;
        }

        submitBtn.disabled = true;
        const origText = submitBtn.textContent;
        submitBtn.textContent = "Memproses...";

        try {
            // Ambil MID dulu
            const midResp = await new Promise(r => chrome.runtime.sendMessage({ type: "GET_MACHINE_ID" }, r));
            if (!midResp || !midResp.machineId) {
                errEl.textContent = "Gagal generate MID. Coba lagi.";
                errEl.style.display = "block";
                return;
            }

            // Nama auto dari prefix email
            const name = email.split("@")[0].replace(/[._-]+/g, " ").replace(/\b\w/g, c => c.toUpperCase());

            // Kirim ke backend via background
            const resp = await new Promise(r => chrome.runtime.sendMessage({
                type: "CLAIM_TRIAL",
                payload: { name, email, tool: "coretax-toolkit", machine_id: midResp.machineId },
            }, r));

            if (!resp || !resp.ok) {
                errEl.textContent = "Gagal menghubungi server: " + ((resp && resp.error) || "unknown");
                errEl.style.display = "block";
                return;
            }

            const data = resp.data;

            if (data.success && data.license_key) {
                okEl.textContent = "Trial berhasil! Mengaktifkan...";
                okEl.style.display = "block";
                // Auto-fill + activate
                const ta = document.getElementById("license-input");
                if (ta) ta.value = data.license_key;
                await new Promise(r => setTimeout(r, 500));
                closeModal();
                const actBtn = document.getElementById("activate");
                if (actBtn) actBtn.click();
                return;
            }

            if (data.already_trialed && data.is_active && data.license_key) {
                okEl.textContent = "Trial aktif. Mengaktifkan...";
                okEl.style.display = "block";
                const ta = document.getElementById("license-input");
                if (ta) ta.value = data.license_key;
                await new Promise(r => setTimeout(r, 500));
                closeModal();
                const actBtn = document.getElementById("activate");
                if (actBtn) actBtn.click();
                return;
            }

            if (data.already_trialed && !data.is_active) {
                errEl.innerHTML = "Email ini sudah pernah trial dan sudah kadaluarsa. <a href='https://wa.me/6287888370395?text=Halo%2C%20saya%20mau%20upgrade%20ke%20Pro' target='_blank' style='color:#25D366;font-weight:700'>Upgrade ke Pro</a>";
                errEl.style.display = "block";
                return;
            }

            if (data.suspended) {
                errEl.innerHTML = "Trial di-suspend sampai " + (data.until || "-") + ". Hubungi admin.";
                errEl.style.display = "block";
                return;
            }

            errEl.textContent = (data.error || data.reason || "Gagal memproses trial.");
            errEl.style.display = "block";
        } catch (e) {
            errEl.textContent = "Error: " + e.message;
            errEl.style.display = "block";
        } finally {
            submitBtn.disabled = false;
            submitBtn.textContent = origText;
        }
    }
})();

// ============================================================
(function() {
    // Pastikan dipanggil SETELAH DOM ready
    function init() {
        // Event delegation di document — semua klik ketangkep
        document.addEventListener("click", function(e) {
            var t = e.target;
            // Cari button di ancestor (kalau user klik icon/text di dalam button)
            while (t && t !== document) {
                if (t.id === "claimTrialBtn") { e.preventDefault(); openClaimModal(); return; }
                if (t.id === "waBtn") { e.preventDefault(); window.open("https://wa.me/6287888370395?text=Halo%2C%20saya%20mau%20tanya%20produk%20DevAccTra", "_blank"); return; }
                if (t.id === "dashBtn") { e.preventDefault(); window.open("https://asptrdetraflow.github.io/DevAccTra/dashboard/", "_blank"); return; }
                if (t.id === "claimCancelBtn") { e.preventDefault(); closeClaimModal(); return; }
                if (t.id === "claimSubmitBtn") { e.preventDefault(); doClaim(); return; }
                t = t.parentElement;
            }
            // Klik backdrop modal = tutup
            if (e.target.id === "claimTrialModal") closeClaimModal();
        });

        // Enter di input email = submit
        var em = document.getElementById("claimEmail");
        if (em) em.addEventListener("keydown", function(e) { if (e.key === "Enter") { e.preventDefault(); doClaim(); } });
    }

    function openClaimModal() {
        var m = document.getElementById("claimTrialModal");
        if (!m) { console.error("[Claim] Modal not found"); return; }
        m.style.display = "flex";
        var e1 = document.getElementById("claimErr"); if (e1) e1.style.display = "none";
        var o1 = document.getElementById("claimOk");  if (o1) o1.style.display = "none";
        var em = document.getElementById("claimEmail"); if (em) { em.value = ""; setTimeout(function(){ em.focus(); }, 100); }
    }
    function closeClaimModal() {
        var m = document.getElementById("claimTrialModal");
        if (m) m.style.display = "none";
    }

    function setErr(msg) {
        var e1 = document.getElementById("claimErr");
        var o1 = document.getElementById("claimOk");
        if (o1) o1.style.display = "none";
        if (e1) { e1.innerHTML = msg; e1.style.display = "block"; }
    }
    function setOk(msg) {
        var e1 = document.getElementById("claimErr");
        var o1 = document.getElementById("claimOk");
        if (e1) e1.style.display = "none";
        if (o1) { o1.innerHTML = msg; o1.style.display = "block"; }
    }

    async function doClaim() {
        var em = document.getElementById("claimEmail");
        var btn = document.getElementById("claimSubmitBtn");
        var email = (em && em.value || "").trim().toLowerCase();
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { setErr("Format email tidak valid."); return; }
        if (btn) { btn.disabled = true; btn.textContent = "Memproses..."; }

        try {
            var midResp = await new Promise(function(r) {
                chrome.runtime.sendMessage({ type: "GET_MACHINE_ID" }, function(resp) { r(resp); });
            });
            if (!midResp || !midResp.machineId) { setErr("Gagal generate MID. Coba lagi."); return; }

            var name = email.split("@")[0].replace(/[._-]+/g, " ").replace(/\b\w/g, function(c) { return c.toUpperCase(); });

            var resp = await new Promise(function(r) {
                chrome.runtime.sendMessage({
                    type: "CLAIM_TRIAL",
                    payload: { name: name, email: email, tool: "coretax-toolkit", machine_id: midResp.machineId }
                }, function(resp) { r(resp); });
            });

            if (!resp || !resp.ok) { setErr("Gagal menghubungi server: " + ((resp && resp.error) || "unknown")); return; }

            var data = resp.data;

            // KASUS 1: Trial baru berhasil generate
            if (data.success && data.license_key) {
                setOk("🎉 Trial aktif! Mengaktifkan license...");
                var ta = document.getElementById("license-input");
                if (ta) ta.value = data.license_key;
                setTimeout(function() {
                    closeClaimModal();
                    var actBtn = document.getElementById("activate");
                    if (actBtn) actBtn.click();
                }, 700);
                return;
            }

            // KASUS 2: Email sudah trial + AKTIF (MID sama) → countdown 10 detik
            if (data.already_trialed && data.is_active && !data.on_different_device && data.license_key) {
                var secondsLeft = 10;
                var expDate = data.expires_at || "-";
                setOk(
                    "ℹ️ <b>Email ini sudah pernah trial</b><br>" +
                    "Trial aktif sampai <b>" + expDate + "</b><br><br>" +
                    "Auto-activate dalam <b id=\"countdownNum\">" + secondsLeft + "</b> detik..."
                );
                var ta2 = document.getElementById("license-input");
                if (ta2) ta2.value = data.license_key;

                var timer = setInterval(function() {
                    secondsLeft--;
                    var num = document.getElementById("countdownNum");
                    if (num) num.textContent = secondsLeft;
                    if (secondsLeft <= 0) {
                        clearInterval(timer);
                        closeClaimModal();
                        var actBtn = document.getElementById("activate");
                        if (actBtn) actBtn.click();
                    }
                }, 1000);

                // Cancel button buat skip countdown
                var cancelBtn = document.getElementById("claimCancelBtn");
                if (cancelBtn) {
                    var origCancel = cancelBtn.onclick;
                    cancelBtn.onclick = function() {
                        clearInterval(timer);
                        closeClaimModal();
                        if (typeof origCancel === "function") origCancel();
                    };
                }
                return;
            }

            // KASUS 3: Email sudah trial tapi di DEVICE LAIN → TOLAK
            if (data.already_trialed && data.on_different_device) {
                setErr(
                    "🚫 <b>Email ini sudah trial di device lain</b><br>" +
                    "MID device lama: <code style='font-size:10px'>" + (data.existing_mid_short || "-") + "</code><br>" +
                    "Trial aktif sampai: <b>" + (data.expires_at || "-") + "</b><br><br>" +
                    "Trial hanya berlaku untuk 1 device. Untuk pindah device, hubungi admin.<br><br>" +
                    "<a href='https://wa.me/6287888370395?text=Halo%2C%20saya%20mau%20pindah%20device%20untuk%20trial' target='_blank' style='display:inline-block;margin-top:6px;padding:8px 14px;background:#25D366;color:#fff;border-radius:6px;text-decoration:none;font-weight:800;font-size:10.5px'>💬 Hubungi Admin</a>"
                );
                return;
            }

            // KASUS 4: Max trials reached (3x)
            if (data.max_trials_reached) {
                setErr(
                    "🚫 <b>Batas trial tercapai</b><br>" +
                    (data.reason || "Anda sudah trial 3x untuk produk ini.") +
                    "<br><br>" +
                    "<a href='https://wa.me/6287888370395?text=Halo%2C%20saya%20mau%20upgrade%20ke%20Pro' target='_blank' style='display:inline-block;margin-top:6px;padding:8px 14px;background:#25D366;color:#fff;border-radius:6px;text-decoration:none;font-weight:800;font-size:10.5px'>💬 Upgrade ke Pro</a>"
                );
                return;
            }

            if (data.suspended) { setErr("🚫 Trial di-suspend sampai <b>" + (data.until || "-") + "</b>. Hubungi admin."); return; }

            setErr(data.error || data.reason || "Gagal memproses trial.");
        } catch (err) {
            setErr("Error: " + (err && err.message || "unknown"));
        } finally {
            if (btn) { btn.disabled = false; btn.textContent = "Mulai Trial"; }
        }
    }

    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
    else init();
})();

// ============================================================
// CTA HANDLER v2 — CSP-safe (no inline onclick), countdown guard
// ============================================================
(function() {
    var _countdownTimer = null;
    var _countdownActive = false;

    function stopCountdown() {
        if (_countdownTimer) { clearInterval(_countdownTimer); _countdownTimer = null; }
        _countdownActive = false;
    }

    function openClaimModal() {
        var m = document.getElementById("claimTrialModal");
        if (!m) return;
        m.style.display = "flex";
        var e1 = document.getElementById("claimErr"); if (e1) e1.style.display = "none";
        var o1 = document.getElementById("claimOk");  if (o1) o1.style.display = "none";
        var em = document.getElementById("claimEmail"); if (em) { em.value = ""; setTimeout(function(){ em.focus(); }, 100); }
        var sb = document.getElementById("claimSubmitBtn");
        if (sb) { sb.disabled = false; sb.textContent = "Mulai Trial"; sb.style.background = ""; sb.style.cursor = "pointer"; }
        stopCountdown();
    }
    function closeClaimModal() {
        stopCountdown();
        var m = document.getElementById("claimTrialModal");
        if (m) m.style.display = "none";
        var sb = document.getElementById("claimSubmitBtn");
        if (sb) { sb.disabled = false; sb.textContent = "Mulai Trial"; sb.style.background = ""; sb.style.cursor = "pointer"; }
    }

    function setErr(msg) {
        var e1 = document.getElementById("claimErr");
        var o1 = document.getElementById("claimOk");
        if (o1) o1.style.display = "none";
        if (e1) { e1.innerHTML = msg; e1.style.display = "block"; }
    }
    function setOk(msg) {
        var e1 = document.getElementById("claimErr");
        var o1 = document.getElementById("claimOk");
        if (e1) e1.style.display = "none";
        if (o1) { o1.innerHTML = msg; o1.style.display = "block"; }
    }

    async function doClaim() {
        // Guard: kalau countdown lagi jalan, jangan re-trigger
        if (_countdownActive) return;

        var em = document.getElementById("claimEmail");
        var btn = document.getElementById("claimSubmitBtn");
        var email = (em && em.value || "").trim().toLowerCase();
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { setErr("Format email tidak valid."); return; }
        if (btn) { btn.disabled = true; btn.textContent = "Memproses..."; }

        try {
            var midResp = await new Promise(function(r) {
                chrome.runtime.sendMessage({ type: "GET_MACHINE_ID" }, function(resp) { r(resp); });
            });
            if (!midResp || !midResp.machineId) { setErr("Gagal generate MID. Coba lagi."); if (btn) { btn.disabled = false; btn.textContent = "Mulai Trial"; } return; }

            var name = email.split("@")[0].replace(/[._-]+/g, " ").replace(/\b\w/g, function(c) { return c.toUpperCase(); });

            var resp = await new Promise(function(r) {
                chrome.runtime.sendMessage({
                    type: "CLAIM_TRIAL",
                    payload: { name: name, email: email, tool: "coretax-toolkit", machine_id: midResp.machineId }
                }, function(resp) { r(resp); });
            });

            if (!resp || !resp.ok) { setErr("Gagal menghubungi server: " + ((resp && resp.error) || "unknown")); if (btn) { btn.disabled = false; btn.textContent = "Mulai Trial"; } return; }

            var data = resp.data;

            // ============================================
            // KASUS 1: Trial baru berhasil
            // ============================================
            if (data.success && data.license_key) {
                setOk("🎉 Trial aktif! Mengaktifkan license...");
                var ta = document.getElementById("license-input");
                if (ta) ta.value = data.license_key;
                setTimeout(function() {
                    closeClaimModal();
                    var actBtn = document.getElementById("activate");
                    if (actBtn) actBtn.click();
                }, 700);
                return;
            }

            // ============================================
            // KASUS 2: Email sudah trial + AKTIF (MID sama) → countdown 10 detik DI TOMBOL
            // ============================================
            if (data.already_trialed && data.is_active && !data.on_different_device && data.license_key) {
                var secondsLeft = 10;
                var expDate = data.expires_at || "-";
                setOk(
                    "ℹ️ <b>Email ini sudah pernah trial</b><br>" +
                    "Trial aktif sampai <b>" + expDate + "</b><br><br>" +
                    "Auto-activate dalam <b>" + secondsLeft + "</b> detik..."
                );
                var ta2 = document.getElementById("license-input");
                if (ta2) ta2.value = data.license_key;

                // Update tombol jadi countdown
                if (btn) {
                    btn.disabled = true;
                    btn.style.cursor = "not-allowed";
                    btn.style.background = "linear-gradient(135deg,#004D2F 0%,#003521 100%)";
                    btn.textContent = "Auto-activate (" + secondsLeft + "s)";
                }
                _countdownActive = true;

                _countdownTimer = setInterval(function() {
                    secondsLeft--;
                    // Update countdown di tombol
                    if (btn) btn.textContent = "Auto-activate (" + secondsLeft + "s)";
                    // Update countdown di text
                    var okEl = document.getElementById("claimOk");
                    if (okEl) {
                        okEl.innerHTML = "ℹ️ <b>Email ini sudah pernah trial</b><br>Trial aktif sampai <b>" + expDate + "</b><br><br>Auto-activate dalam <b>" + secondsLeft + "</b> detik...";
                    }
                    if (secondsLeft <= 0) {
                        stopCountdown();
                        closeClaimModal();
                        var actBtn = document.getElementById("activate");
                        if (actBtn) actBtn.click();
                    }
                }, 1000);
                return;
            }

            // ============================================
            // KASUS 3: Email trial di DEVICE LAIN
            // ============================================
            if (data.already_trialed && data.on_different_device) {
                setErr(
                    "🚫 <b>Email ini sudah trial di device lain</b><br>" +
                    "MID device lama: <code style='font-size:10px'>" + (data.existing_mid_short || "-") + "</code><br>" +
                    "Trial aktif sampai: <b>" + (data.expires_at || "-") + "</b><br><br>" +
                    "Trial hanya berlaku untuk 1 device. Untuk pindah device, hubungi admin.<br><br>" +
                    "<a href='https://wa.me/6287888370395?text=Halo%2C%20saya%20mau%20pindah%20device%20untuk%20trial' target='_blank' style='display:inline-block;margin-top:6px;padding:8px 14px;background:#25D366;color:#fff;border-radius:6px;text-decoration:none;font-weight:800;font-size:10.5px'>💬 Hubungi Admin</a>"
                );
                if (btn) { btn.disabled = false; btn.textContent = "Mulai Trial"; }
                return;
            }

            // ============================================
            // KASUS 4: Max trials reached (3x)
            // ============================================
            if (data.max_trials_reached) {
                setErr(
                    "🚫 <b>Batas trial tercapai</b><br>" +
                    (data.reason || "Anda sudah trial 3x untuk produk ini.") +
                    "<br><br>" +
                    "<a href='https://wa.me/6287888370395?text=Halo%2C%20saya%20mau%20upgrade%20ke%20Pro' target='_blank' style='display:inline-block;margin-top:6px;padding:8px 14px;background:#25D366;color:#fff;border-radius:6px;text-decoration:none;font-weight:800;font-size:10.5px'>💬 Upgrade ke Pro</a>"
                );
                if (btn) { btn.disabled = false; btn.textContent = "Mulai Trial"; }
                return;
            }

            if (data.suspended) { setErr("🚫 Trial di-suspend sampai <b>" + (data.until || "-") + "</b>. Hubungi admin."); if (btn) { btn.disabled = false; btn.textContent = "Mulai Trial"; } return; }

            setErr(data.error || data.reason || "Gagal memproses trial.");
            if (btn) { btn.disabled = false; btn.textContent = "Mulai Trial"; }
        } catch (err) {
            setErr("Error: " + (err && err.message || "unknown"));
            if (btn) { btn.disabled = false; btn.textContent = "Mulai Trial"; }
        }
    }

    function init() {
        var claimBtn = document.getElementById("claimTrialBtn");
        var waBtn = document.getElementById("waBtn");
        var dashBtn = document.getElementById("dashBtn");
        var cancelBtn = document.getElementById("claimCancelBtn");
        var submitBtn = document.getElementById("claimSubmitBtn");
        var modal = document.getElementById("claimTrialModal");
        var emailInput = document.getElementById("claimEmail");

        if (claimBtn) claimBtn.addEventListener("click", function(e) { e.preventDefault(); openClaimModal(); });
        if (waBtn) waBtn.addEventListener("click", function(e) { e.preventDefault(); window.open("https://wa.me/6287888370395?text=Halo%2C%20saya%20mau%20tanya%20produk%20DevAccTra", "_blank"); });
        if (dashBtn) dashBtn.addEventListener("click", function(e) { e.preventDefault(); window.open("https://asptrdetraflow.github.io/DevAccTra/dashboard/", "_blank"); });
        if (cancelBtn) cancelBtn.addEventListener("click", function(e) { e.preventDefault(); closeClaimModal(); });
        if (submitBtn) submitBtn.addEventListener("click", function(e) { e.preventDefault(); doClaim(); });
        if (modal) modal.addEventListener("click", function(e) { if (e.target === modal) closeClaimModal(); });
        if (emailInput) emailInput.addEventListener("keydown", function(e) { if (e.key === "Enter" && !_countdownActive) { e.preventDefault(); doClaim(); } });

        // Email input focus styling (ganti onfocus/onblur inline)
        if (emailInput) {
            emailInput.addEventListener("focus", function() { this.style.borderColor = "#004D2F"; this.style.outline = "none"; });
            emailInput.addEventListener("blur", function() { this.style.borderColor = "#d1d5db"; });
        }
    }

    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
    else init();
})();