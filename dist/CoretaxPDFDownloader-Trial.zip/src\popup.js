const licenseSection = document.getElementById("license-section");
const activeSection = document.getElementById("active-section");
const machineIdEl = document.getElementById("machine-id");
const licenseInput = document.getElementById("license-input");
const licenseMessage = document.getElementById("license-message");
const licenseInfo = document.getElementById("license-info");
const statusAuth = document.getElementById("status-auth");

function send(m) { return new Promise(r => chrome.runtime.sendMessage(m, r)); }

async function init() {
    const status = await send({ type: "GET_LICENSE_STATUS" });
    machineIdEl.textContent = status.machineId;

    if (status.activated) {
        const check = await send({ type: "CHECK_LICENSE_NOW" });
        if (check && check.valid === false) {
            licenseSection.classList.remove("hidden");
            activeSection.classList.add("hidden");
            licenseMessage.innerHTML = '<span class="bad">✕ ' + (check.reason || "License sudah dicabut.") + '</span>';
            return;
        }
    }

    if (status.activated && status.valid) {
        licenseSection.classList.add("hidden");
        activeSection.classList.remove("hidden");
        licenseInfo.innerHTML = 'Expired: <b>' + (status.expiresAt || "-") + '</b><br>Tier: <b>' + (status.tier || "pro") + '</b>';
        await refreshStatus();
    } else {
        licenseSection.classList.remove("hidden");
        activeSection.classList.add("hidden");
        if (status.activated && !status.valid) {
            licenseMessage.innerHTML = '<span class="bad">License tidak valid: ' + status.reason + '</span>';
        }
    }
}

async function refreshStatus() {
    const status = await send({ type: "GET_STATUS" });
    if (!status.success) return;
    const lines = [];
    lines.push(status.authCaptured ? '<span class="ok">✓</span> Authorization tertangkap' : '<span class="bad">✕</span> Authorization belum');
    lines.push(status.xDgtCaptured ? '<span class="ok">✓</span> x-dgt-code tertangkap' : '<span class="bad">✕</span> x-dgt-code belum');
    const hasAny = status.hasInput || status.hasOutput || status.hasWithholding;
    lines.push(hasAny ? '<span class="ok">✓</span> Data list tertangkap' : '<span class="bad">✕</span> Belum ada list');
    statusAuth.innerHTML = lines.join("<br>");

    // Force check backend
    const check = await send({ type: "CHECK_LICENSE_NOW" });
    if (check && check.valid === false) {
        alert("⚠️ License tidak valid:\n\n" + (check.reason || "Sudah dicabut oleh admin."));
        setTimeout(init, 300);
    }
}

document.getElementById("copy-machine").addEventListener("click", async () => {
    await navigator.clipboard.writeText(machineIdEl.textContent);
    const btn = document.getElementById("copy-machine");
    btn.textContent = "✓ Copied";
    setTimeout(() => btn.textContent = "Copy Machine ID", 1500);
});

document.getElementById("activate").addEventListener("click", async () => {
    const key = licenseInput.value.trim();
    if (!key) { licenseMessage.innerHTML = '<span class="bad">License kosong.</span>'; return; }
    licenseMessage.textContent = "Memverifikasi...";
    const result = await send({ type: "ACTIVATE_LICENSE", licenseKey: key });
    if (result.success) {
        licenseMessage.innerHTML = '<span class="ok">✓ License berhasil!' + (result.autoSynced ? ' (auto-sync)' : '') + '</span>';
        setTimeout(init, 600);
    } else licenseMessage.innerHTML = '<span class="bad">✕ ' + result.error + '</span>';
});

async function doSync() {
    const btns = [document.getElementById("syncBtn"), document.getElementById("syncBtnActive")].filter(b => b);
    btns.forEach(b => { b.disabled = true; b.textContent = "Syncing..."; });
    try {
        // Kalau textarea ada license tapi belum ke-save → save dulu
        const ta = document.getElementById("license-input");
        if (ta && ta.value.trim()) {
            const current = await send({ type: "GET_LICENSE_STATUS" });
            if (!current.activated || !current.payload) {
                // Belum ada license di storage → coba activate dulu
                const act = await send({ type: "ACTIVATE_LICENSE", licenseKey: ta.value.trim() });
                if (!act.success && isMismatchError(act.error)) {
                    const mid = (await send({ type: "GET_MACHINE_ID" })).machineId || "";
                    showRebindModal(mid, ta.value.trim(), "License untuk device lain. Masukkan MID device lama untuk sinkronisasi.");
                    return;
                }
                if (act.success) {
                    licenseMessage.innerHTML = '<span class="ok">✓ License tersimpan.' + (act.autoSynced ? ' (auto-sync)' : '') + '</span>';
                    setTimeout(init, 600);
                    return;
                }
                // Activate gagal karena alasan lain
                licenseMessage.innerHTML = '<span class="bad">✕ ' + act.error + '</span>';
                return;
            }
        }

        const res = await send({ type: "SYNC_LICENSE_WITH_BACKEND" });
        if (res && res.success) {
            licenseMessage.innerHTML = '<span class="ok">✓ ' + (res.message || "Sync berhasil") + '</span>';
            setTimeout(init, 600);
        } else {
            const err = (res && res.error) || "Sync gagal";
            licenseMessage.innerHTML = '<span class="bad">✕ ' + err + '</span>';
            if (isMismatchError(err)) {
                const mid = (await send({ type: "GET_MACHINE_ID" })).machineId || "";
                const ta2 = document.getElementById("license-input");
                showRebindModal(mid, ta2 ? ta2.value.trim() : "", "License untuk device lain. Masukkan MID device lama untuk sinkronisasi.");
            }
        }
    } finally {
        btns.forEach(b => { b.disabled = false; b.textContent = "🔄 Sync"; });
    }
}

const syncBtn = document.getElementById("syncBtn");
if (syncBtn) syncBtn.addEventListener("click", doSync);
const syncBtnActive = document.getElementById("syncBtnActive");
if (syncBtnActive) syncBtnActive.addEventListener("click", doSync);

document.getElementById("refresh-status").addEventListener("click", refreshStatus);
document.getElementById("reset-license").addEventListener("click", async () => {
    if (!confirm("Reset license?")) return;
    await send({ type: "RESET_LICENSE" });
    setTimeout(init, 300);
});

init();


// ============================================================
// REBIND MODAL — untuk handle MID mismatch
// ============================================================
function showRebindModal(currentMid, prefilledKey, errorMsg) {
    const modal = document.getElementById("rebindModal");
    if (!modal) return;
    document.getElementById("rebindCurrentMid").textContent = currentMid || "-";
    document.getElementById("rebindOldMid").value = "";
    const errEl = document.getElementById("rebindErr");
    errEl.classList.remove("show");
    if (errorMsg) { errEl.textContent = errorMsg; errEl.classList.add("show"); }
    modal.classList.add("show");
    setTimeout(() => document.getElementById("rebindOldMid").focus(), 150);

    // Wire buttons (idempotent — pakai onclick overwrite)
    document.getElementById("rebindCancel").onclick = () => {
        modal.classList.remove("show");
    };
    document.getElementById("rebindConfirm").onclick = async () => {
        const oldMid = document.getElementById("rebindOldMid").value.trim();
        errEl.classList.remove("show");

        if (!/^[a-f0-9]{64}$/.test(oldMid)) {
            errEl.textContent = "MID harus 64 karakter hex (a-f, 0-9).";
            errEl.classList.add("show");
            return;
        }
        if (oldMid === currentMid) {
            errEl.textContent = "MID lama sama dengan device ini. Cari MID dari device lain.";
            errEl.classList.add("show");
            return;
        }

        // Ambil license dari storage atau textarea
        let license = prefilledKey || "";
        if (!license) {
            const ta = document.getElementById("license-input");
            license = ta ? ta.value.trim() : "";
        }
        if (!license) {
            errEl.textContent = "Belum ada license. Paste dulu di kolom License Key.";
            errEl.classList.add("show");
            return;
        }

        const btn = document.getElementById("rebindConfirm");
        btn.disabled = true;
        btn.textContent = "Memproses...";

        try {
            const res = await send({
                type: "REBIND_LICENSE",
                license_key: license,
                old_machine_id: oldMid,
                new_machine_id: currentMid,
            });
            if (res && res.success) {
                btn.textContent = "Berhasil!";
                setTimeout(() => {
                    modal.classList.remove("show");
                    init();
                }, 600);
            } else {
                errEl.textContent = (res && res.error) || "Gagal sinkron. Periksa MID lama Anda.";
                errEl.classList.add("show");
                btn.disabled = false;
                btn.textContent = "Sinkronkan";
            }
        } catch (e) {
            errEl.textContent = "Error: " + e.message;
            errEl.classList.add("show");
            btn.disabled = false;
            btn.textContent = "Sinkronkan";
        }
    };
}

function isMismatchError(msg) {
    if (!msg) return false;
    const m = msg.toLowerCase();
    return m.includes("device") || m.includes("cocok") || m.includes("lain") || m.includes("mid");
}

// ============================================================
// Override Activate handler
// ============================================================
const _origInit = init;
init = async function() {
    await _origInit();
    // Re-wire activate button setelah init
    const actBtn = document.getElementById("activate");
    if (actBtn && !actBtn.dataset.rebound) {
        actBtn.dataset.rebound = "1";
        // Remove original listeners by cloning
        const clone = actBtn.cloneNode(true);
        actBtn.parentNode.replaceChild(clone, actBtn);
        clone.addEventListener("click", async () => {
            const key = document.getElementById("license-input").value.trim();
            const msg = document.getElementById("license-message");
            if (!key) { msg.innerHTML = '<span class="bad">License kosong.</span>'; return; }
            msg.textContent = "Memverifikasi...";
            const result = await send({ type: "ACTIVATE_LICENSE", licenseKey: key });
            if (result.success) {
                msg.innerHTML = '<span class="ok">✓ License berhasil!' + (result.autoSynced ? ' (auto-sync)' : '') + '</span>';
                setTimeout(init, 600);
            } else {
                msg.innerHTML = '<span class="bad">✕ ' + result.error + '</span>';
                if (isMismatchError(result.error)) {
                    const mid = (await send({ type: "GET_MACHINE_ID" })).machineId || "";
                    showRebindModal(mid, key, "License ini untuk device lain. Masukkan MID device lama untuk sinkronisasi.");
                }
            }
        });
    }
};

// Override Sync handler
const _origSync = typeof doSync === "function" ? doSync : null;
